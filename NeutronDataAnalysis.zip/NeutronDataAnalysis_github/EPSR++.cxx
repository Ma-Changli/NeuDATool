// EPSR++ is an open source C++ program for neutron data analysis. It is developed
// in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
// (CSNS) by Changli Ma (machangli@ihep.ac.cn).
// EPSR++ adheres to GNU General Public License 2 (GPLv2).

#include  "NDA_header_main.h"

using namespace std;

//#define  ANALYZE_H2O 
//#define  ANALYZE_SiO2 

//define  ANALYZE_H2O_JMOL 
//#define  ANALYZE_ETHANOL_80 
//#define  ANALYZE_PDEA_80 

//#define  ANALYZE_H2O_BOXSHAPE 
//#define  ANALYZE_DMSO_90 
//#define  ANALYZE_DMSO_50 
#define  ANALYZE_DMSO_60 
//#define  ANALYZE_DMSO_70 
//#define  ANALYZE_DMSO_80 

int main(int argc, char* argv[])
{


    cout << " int " << sizeof(int) <<endl;
    cout << " long int " << sizeof(long int) <<endl;
    cout << " long  " << sizeof(long ) <<endl;
    cout << " long long int " << sizeof(long long int) <<endl;
    cout << " unsigned long long int " << sizeof(unsigned long long int) <<endl;
    //exit(0);

    argc_glob = argc;
    argv_glob = argv;

#ifdef USE_MPI
    MPI::Init(argc, argv);
    num_procs   = MPI::COMM_WORLD.Get_size();
    index_procs = MPI::COMM_WORLD.Get_rank();
    cout<<"  Using MPI ... ..." <<endl;
#else 
    num_procs   = 1;
    index_procs = 0;
    cout<<"  Not Using MPI ... ..." <<endl;
#endif 

#ifdef  ANALYZE_H2O
    NDA_FUNC_MAIN::Set_Para_ExpData_H2O();
#endif 


#ifdef  ANALYZE_H2O_BOXSHAPE
    NDA_FUNC_MAIN::Set_Para_ExpData_H2O_BoxShape();
#endif 


#ifdef  ANALYZE_H2O_JMOL
    NDA_FUNC_MAIN::Set_Para_ExpData_H2O_JMOL();
#endif 

#ifdef  ANALYZE_ETHANOL_80
    NDA_FUNC_MAIN::Set_Para_ExpData_ETHANOL_80();
#endif 

#ifdef  ANALYZE_DMSO_90
    NDA_FUNC_MAIN::Set_Para_ExpData_DMSO_90();
#endif 

#ifdef  ANALYZE_DMSO_50
    NDA_FUNC_MAIN::Set_Para_ExpData_DMSO_50();
#endif 

#ifdef  ANALYZE_DMSO_60
    NDA_FUNC_MAIN::Set_Para_ExpData_DMSO_60();
#endif 

#ifdef  ANALYZE_DMSO_70
    NDA_FUNC_MAIN::Set_Para_ExpData_DMSO_70();
#endif 

#ifdef  ANALYZE_DMSO_80
    NDA_FUNC_MAIN::Set_Para_ExpData_DMSO_80();
#endif 

#ifdef  ANALYZE_PDEA_80
    NDA_FUNC_MAIN::Set_Para_ExpData_PDEA_80();
#endif 


#ifdef  ANALYZE_SiO2 
    NDA_FUNC_MAIN::Set_Para_ExpData_SiO2();
#endif 

    NDA_FUNC_MAIN::Set_Para_Run();

    if(is_print_debug_info) NDA_FUNC_MAIN::Print_Debug_Info_Init();

    cout<<"  NDA_FUNC_INIT_SIMUBOX::Init_SimuBox();" <<endl;

#ifdef  ANALYZE_H2O
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_H2O();
#endif 

#ifdef  ANALYZE_H2O_BOXSHAPE
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_H2O_BoxShape();
#endif 

#ifdef  ANALYZE_H2O_JMOL
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_H2O_JMOL();
#endif 


#ifdef  ANALYZE_ETHANOL_80
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_ETHANOL_80();
#endif 

#ifdef  ANALYZE_DMSO_90
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_DMSO_90();
#endif 

#ifdef  ANALYZE_DMSO_50
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_DMSO_50();
#endif 

#ifdef  ANALYZE_DMSO_60
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_DMSO_60();
#endif 

#ifdef  ANALYZE_DMSO_70
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_DMSO_70();
#endif 

#ifdef  ANALYZE_DMSO_80
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_DMSO_80();
#endif 

#ifdef  ANALYZE_PDEA_80
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_PDEA_80();
#endif 


#ifdef  ANALYZE_SiO2 
    NDA_FUNC_INIT_SIMUBOX::Init_SimuBox_SiO2();
#endif 

    cout<<"  NDA_FUNC_INIT_SIMUBOX::Set_Info_Box(); " <<endl;

    NDA_FUNC_INIT_SIMUBOX::Set_Info_Box();

#ifdef USE_MPI 
    NDA_FUNC_MPI_BCAST::Broadcast_Simubox();
#endif
    cout<<"  NDA_FUNC_INIT_SIMUBOX::Print_Info_Box();" <<endl;
    NDA_FUNC_INIT_SIMUBOX::Print_Info_Box();
    NDA_FUNC_INIT_SIMUBOX::Print_Box_To_Gro();


#ifdef ANALYZE_H2O_BOXSHAPE 
    exit(0);
#endif


#ifdef ANALYZE_H2O
    NDA_FUNC_REFPOT::Set_AtomType_H2O();
#endif 

#ifdef ANALYZE_H2O_JMOL
    NDA_FUNC_REFPOT::Set_AtomType_H2O_JMOL();
#endif 
//exit(0);
////Edit Here 


#ifdef ANALYZE_ETHANOL_80
    NDA_FUNC_REFPOT::Set_AtomType_ETHANOL_80();
#endif 

#ifdef ANALYZE_DMSO_90
    NDA_FUNC_REFPOT::Set_AtomType_DMSO_90();
#endif 

#ifdef ANALYZE_DMSO_50
    NDA_FUNC_REFPOT::Set_AtomType_DMSO_50();
#endif 

#ifdef ANALYZE_DMSO_60
    NDA_FUNC_REFPOT::Set_AtomType_DMSO_60();
#endif 

#ifdef ANALYZE_DMSO_70
    NDA_FUNC_REFPOT::Set_AtomType_DMSO_70();
#endif 

#ifdef ANALYZE_DMSO_80
    NDA_FUNC_REFPOT::Set_AtomType_DMSO_80();
#endif 

#ifdef ANALYZE_PDEA_80
    NDA_FUNC_REFPOT::Set_AtomType_PDEA_80();
#endif 


#ifdef  ANALYZE_SiO2 
    NDA_FUNC_REFPOT::Set_AtomType_SiO2();
#endif 

    NDA_FUNC_MAIN::Init_AtomType();

#ifdef USE_MPI
    MPI::COMM_WORLD.Barrier();
#endif

    NDA_FUNC_NEW_ARRAY_ATOMTYPE::New_Array_AtomType();

    NDA_FUNC_ATOMTYPE::Set_Para_AtomType();

    NDA_FUNC_ATOMTYPE::Print_Para_AtomType();

    NDA_FUNC_NEW_ARRAY_PDFPOT::New_Array_RefPot();

#ifdef ANALYZE_H2O
    NDA_FUNC_REFPOT::Set_Para_RefPot_H2O();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_H2O();
#endif 


#ifdef ANALYZE_H2O_JMOL
    NDA_FUNC_REFPOT::Set_Para_RefPot_H2O_JMOL();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_H2O_JMOL();
#endif 


#ifdef ANALYZE_ETHANOL_80
    NDA_FUNC_REFPOT::Set_Para_RefPot_ETHANOL_80();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_ETHANOL_80();
#endif 


#ifdef ANALYZE_DMSO_90
    NDA_FUNC_REFPOT::Set_Para_RefPot_DMSO_90();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_DMSO_90();
#endif 

#ifdef ANALYZE_DMSO_50
    NDA_FUNC_REFPOT::Set_Para_RefPot_DMSO_50();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_DMSO_50();
#endif 

#ifdef ANALYZE_DMSO_60
    NDA_FUNC_REFPOT::Set_Para_RefPot_DMSO_60();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_DMSO_60();
#endif 

#ifdef ANALYZE_DMSO_70
    NDA_FUNC_REFPOT::Set_Para_RefPot_DMSO_70();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_DMSO_70();
#endif 

#ifdef ANALYZE_DMSO_80
    NDA_FUNC_REFPOT::Set_Para_RefPot_DMSO_80();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_DMSO_80();
#endif 

#ifdef ANALYZE_PDEA_80
    NDA_FUNC_REFPOT::Set_Para_RefPot_PDEA_80();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_PDEA_80();
#endif 


#ifdef  ANALYZE_SiO2 
    NDA_FUNC_REFPOT::Set_Para_RefPot_SiO2();
    NDA_FUNC_REFPOT::Set_Para_RefPot_Cut_SiO2();
#endif 

    cout<<" NDA_FUNC_WEIGHT_MATRIX::Set_Array_RefPot() " << endl;
    NDA_FUNC_REFPOT::Set_Array_RefPot();

#ifdef USE_MPI
    NDA_FUNC_MPI_BCAST::Broadcast_RefPot();
#endif

    cout<<" NDA_FUNC_WEIGHT_MATRIX::Calc_Pot_Box_Init() " << endl;
    NDA_FUNC_PARALLEL_MAIN ::Calc_Pot_Box_Init();


#ifdef USE_MPI
    NDA_FUNC_MPI_BCAST::Broadcast_PotBox();
#endif

    cout<<" NDA_FUNC_WEIGHT_MATRIX::Print_Pot() " << endl;
    NDA_FUNC_PRINTPOT::Print_Pot();

    NDA_FUNC_READ_NSF_DATA::Read_NSF_Data();

    NDA_FUNC_NEW_ARRAY_NSFPOT::New_Array_NSF_BKGD();

    NDA_FUNC_NEW_ARRAY_NSFPOT::New_Array_NSF();

    NDA_FUNC_NEW_MATRIX::New_Matrix_Weight();

    cout<<" NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD() " << endl;
#ifdef ANALYZE_H2O
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_H2O();
#endif 

#ifdef ANALYZE_H2O_JMOL
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_H2O_JMOL();
#endif 


#ifdef ANALYZE_ETHANOL_80
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_ETHANOL_80();
#endif 

#ifdef ANALYZE_DMSO_90
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_DMSO_90();
#endif 

#ifdef ANALYZE_DMSO_50
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_DMSO_50();
#endif 

#ifdef ANALYZE_DMSO_60
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_DMSO_60();
#endif 

#ifdef ANALYZE_DMSO_70
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_DMSO_70();
#endif 

#ifdef ANALYZE_DMSO_80
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_DMSO_80();
#endif 

#ifdef ANALYZE_PDEA_80
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_PDEA_80();
#endif 

#ifdef  ANALYZE_SiO2 
    NDA_FUNC_WEIGHT_MATRIX::Set_Weight_Matrix_BKGD_SiO2();
#endif 

    NDA_FUNC_READ_NSF_DATA::Add_BKGD_NSF_Data();

    // exit(0);
#ifdef USE_MPI
    MPI::COMM_WORLD.Barrier();
#endif

    cout <<"  NDA_FUNC_NEW_ARRAY_PDFPOT::New_Array_PDF();" << endl;
    NDA_FUNC_NEW_ARRAY_PDFPOT::New_Array_PDF();

    cout <<"  NDA_FUNC_NSF_INIT::Calc_NSF_Init() ;  " << endl;
    NDA_FUNC_NSF_INIT::Calc_NSF_Init() ; 

#ifdef USE_MPI
    NDA_FUNC_MPI_BCAST::Broadcast_NSF_Init();
#endif

    cout <<"  NDA_FUNC_NSF_INIT::Print_NSF_Init();" << endl;
    NDA_FUNC_NSF_INIT::Print_NSF_Init();

    cout <<"  NDA_FUNC_NEW_ARRAY_NSFPOT::New_Array_ExpPot();     " << endl;
    NDA_FUNC_NEW_ARRAY_NSFPOT::New_Array_ExpPot();

    cout <<"  NDA_FUNC_EXPPOT::Cal_Exppot();     " << endl;
    NDA_FUNC_EXPPOT::Cal_Exppot();

    cout <<"  NDA_FUNC_NEW_ARRAY_RMCEPSR:: New_Array_RMCEPSR();     " << endl;
    NDA_FUNC_NEW_ARRAY_RMCEPSR:: New_Array_RMCEPSR();

    cout <<"  NDA_FUNC_INIT_VAR_RMCEPSR::Init_Var_RMCEPSR(); " << endl;
    NDA_FUNC_INIT_VAR_RMCEPSR::Init_Var_RMCEPSR();

#ifdef USE_GPU
    cout <<"  NDA_FUNC_NEW_ARRAY_GPU::New_Array_GPU(); " << endl;
    NDA_FUNC_NEW_ARRAY_GPU::New_Array_GPU();
#endif

    cout<<"  Before while(is_continue_simu) :" << endl;


    // while(is_continue_simu)  //for i_move_molatom
    while(true)  //for i_move_molatom
    {
	//	output_file_debug.open("./info_debug.txt",  ofstream::out);

	// Move molecule or atom randomly in process 00 and
	// broadcast the delta coord of moved atoms to other processes
	//	output_file_debug<< "  Before Set_Random_Move_Var();" << endl;
	//cout<< "  Before Set_Random_Move_Var();" << endl;

#ifdef USE_MPI
	if(index_procs == 0)  NDA_FUNC_RMCEPSR::Set_Random_Move_Var();    
#else
	NDA_FUNC_RMCEPSR::Set_Random_Move_Var();    
#endif

	i_move_molatom_try++;

	//	output_file_debug<< "  Finish Set_Random_Move_Var();" << endl;
	//		cout<< "  Finish Set_Random_Move_Var();" << endl;
#ifdef USE_MPI
	NDA_FUNC_MPI_BCAST::Broadcast_Info_Move();
	MPI::COMM_WORLD.Barrier();
#endif

	//	output_file_debug<< "  Before Sort_Moved_Atom();" << endl;
	//	cout<< "  Before Sort_Moved_Atom();" << endl;
	NDA_FUNC_RMCEPSR::Sort_Moved_Atom();

#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif

	//	output_file_debug<< "  Before Calc_Delta_NR_GPU();" << endl;
	//	cout<< "  Before Calc_Delta_NR_GPU();" << endl;
#ifdef USE_GPU
	NDA_FUNC_RMCEPSR::Calc_Delta_NR_GPU();
#else
	NDA_FUNC_RMCEPSR::Calc_Delta_NR_CPU(); 
#endif

#ifdef USE_MPI
	NDA_FUNC_MPI_BCAST :: Broadcast_Delta_NR();
#endif

	is_move_accepted = false;

	//	output_file_debug<< "  Before Decide_Accept_Move();" << endl;
	//	cout<< "  Before Decide_Accept_Move();" << endl;
	NDA_FUNC_RMCEPSR::Decide_Accept_Move();

#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif

	i_move_molatom_samepot_try++;
	// if( !is_move_accepted )  continue; // This can cause endless lool when  is_move_accepted is always false on 20191011!!!
	if(!is_move_accepted && i_move_molatom_samepot_try < num_move_molatom_samepot_max)  continue;

#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif

	//	output_file_debug<< "  Before Confirm_Move_CPU();" << endl;
	//	cout<< "  Before Confirm_Move();" << endl;
	if( is_move_accepted ) 
	{
	    NDA_FUNC_RMCEPSR::Confirm_Move_CPU();
#ifdef USE_GPU 
	    NDA_FUNC_RMCEPSR::Confirm_Move_GPU();
#endif
	}

#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif

	//	output_file_debug<< "  Before Decide_Update_Pot();" << endl;
	//	cout<< "  Before Decide_Update_Pot();" << endl;
	NDA_FUNC_RMCEPSR::Decide_Update_Pot();
	//	output_file_debug<< "  Finish Decide_Update_Pot();" << endl;
	//	cout<< "  Finish Decide_Update_Pot();" << endl;

#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif

	//output_file_debug.close();

	if(should_update_pot) 
	{
	    //  output_file_debug.open("./info_debug.txt",  ofstream::app);
	    //  output_file_debug<< "  Before Print_BoxToGro();" << endl;
	    //  cout<< "  Before Print_BoxToGro();" << endl;
	    //  NDA_FUNC_RMCEPSR::Print_Debug_Info();  
	    NDA_FUNC_RMCEPSR::Print_BoxToGro();

#ifdef USE_MPI
	    MPI::COMM_WORLD.Barrier();
#endif

#ifdef USE_GPU 
	    NDA_FUNC_RMCEPSR::Calc_PDF_GPU();
#else
	    NDA_FUNC_RMCEPSR::Calc_PDF_CPU();
#endif

#ifdef USE_MPI
	    MPI::COMM_WORLD.Barrier();
#endif

	    NDA_FUNC_RMCEPSR::Calc_NSF();

#ifdef USE_MPI
	    NDA_FUNC_MPI_BCAST::Broadcast_NSF_RMCEPSR();
#endif

#ifdef USE_MPI
	    MPI::COMM_WORLD.Barrier();
#endif

	    NDA_FUNC_RMCEPSR::Print_NSF();

#ifdef USE_MPI
	    MPI::COMM_WORLD.Barrier();
#endif

	    NDA_FUNC_RMCEPSR::Print_PDF_NSF_Sum();
	    NDA_FUNC_RMCEPSR::Calc_Chisq_NSF_SimuData();
	    NDA_FUNC_RMCEPSR::Calc_Delta_NSF();        

	    // {// They are in func NDA_FUNC_RMCEPSR::Update_Pot()

	    NDA_FUNC_RMCEPSR::Fit_ExpPot();
	    NDA_FUNC_RMCEPSR::Print_Delta_NSF(); 
	    NDA_FUNC_RMCEPSR::Add_ExpPot_To_RefPot();
	    NDA_FUNC_RMCEPSR::Print_ExpPot();

	    index_update_pot++; 

	    have_update_pot   = true; 
	    accept_ratio_move_cut = accept_ratio_move_cut_ep;

	    should_update_pot = false;

#ifdef USE_MPI
	    MPI::COMM_WORLD.Barrier();
#endif
	    //  }

	    // output_file_debug.close();
	}
#ifdef USE_MPI
	MPI::COMM_WORLD.Barrier();
#endif
    } // End move molecule or atom randomly

    if(index_procs == 0)  output_file_pot.close();

#ifdef USE_GPU
    NDA_FUNC_DELETE_ARRAY_GPU::Delete_Array_GPU();
#endif

#ifdef USE_MPI
    MPI::COMM_WORLD.Barrier();
#endif

#ifdef USE_MPI
    MPI::Finalize();
#endif

    return 0;
}
