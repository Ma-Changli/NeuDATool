//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_PDF_H
#define NDA_FUNC_PDF_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_PDF {



    void Calculate_PDF( 
	    vector< CLHEP::Hep3Vector> coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector> coord_atom_01_vec, 
	    double * r_mean_arr,
	    int     *num_atompair_innuc_arr, 
	    double  *num_atompair_innuc_mean_arr,  
	    double  *pdf_atompair_innuc_arr,  
	    double  *volume_bin_rdf,
	    double   density_nuc_01, 
	    double   boxsize,
	    int      num_bin_pdf
	    );


    void Calculate_PDF_FromNR( 
	    int     *num_atompair_arr, 
	    double  *num_atompair_mean_arr,  
	    double  *pdf_atompair_arr,  
	    double  *volume_bin_pdf_arr,
	    int      num_atom_00,
	    double   density_nuc_01, 
	    int      num_bin_pdf
	    );


    void Calculate_PDF_FromNR( 
	    long     *num_atompair_arr, 
	    double  *num_atompair_mean_arr,  
	    double  *pdf_atompair_arr,  
	    double  *volume_bin_pdf_arr,
	    int      num_atom_00,
	    double   density_nuc_01, 
	    int      num_bin_pdf
	    );

    void Calculate_PDF_FromNR( 
	   unsigned  long long int    *num_atompair_arr, 
	    double  *num_atompair_mean_arr,  
	    double  *pdf_atompair_arr,  
	    double  *volume_bin_pdf_arr,
	    int      num_atom_00,
	    double   density_nuc_01, 
	    int      num_bin_pdf
	    );



    void Calculate_PDF_Reduct( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    vector< std::string >          name_nuc_atom_00_vec, 
	    vector< std::string >          name_nuc_atom_01_vec, 
	    std::map<string, double>       b_nuc_map,
	    double  *r_mean_arr,

	    int     *num_atompair_innuc_arr, 
	    double  *num_atompair_innuc_mean_arr,  
	    double  *pdf_atompair_innuc_arr,  

	    double  *num_atompair_innuc_reduct_arr, 
	    double  *num_atompair_innuc_mean_reduct_arr,  
	    double  *pdf_atompair_innuc_reduct_arr,  

	    double  *volume_bin_pdf_arr,
	    double   density_nuc_01, 
	    double   boxsize,
	    int      num_bin_pdf
	    );




    //==============================================================
    void Calculate_PDF_Reduct_Sample( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    int                            index_atomtype_00_inbox,
	    int                            index_atomtype_01_inbox,
	    vector< vector<  vector< std::string > > >  name_nuc_atom_inepsr_inbox_vec_3d, 
	    int num_sample_exp, 
	    std::map<string, double>       b_nuc_map,
	    double  *r_mean_arr,

	    int     *num_atompair_innuc_arr, 
	    double  *num_atompair_innuc_mean_arr,  
	    double  *pdf_atompair_innuc_arr,  

	    double  **num_atompair_innuc_reduct_arr_2d, 
	    double  **num_atompair_innuc_mean_reduct_arr_2d,  
	    double  **pdf_atompair_innuc_reduct_arr_2d,  

	    double  *volume_bin_pdf_arr,
	    double   density_nuc_01, 
	    double   boxsize,
	    int      num_bin_pdf,
	    double   binsize_pdf_sim
		);



    void Calculate_Delta_PDF_Reduct( 
	    vector< CLHEP::Hep3Vector > coord_atom_00_innuc_vec, 
	    vector< CLHEP::Hep3Vector > coord_atom_01_innuc_vec, 
	    vector< std::string >    name_nuc_atom_00_innuc_vec, 
	    vector< std::string >    name_nuc_atom_01_innuc_vec, 
	    std::map<string, double>       b_nuc_map,

	    int index_nuc_00_inbox,
	    int index_nuc_01_inbox,
	    vector< int >             index_nuc_moved_inbox_vec,
	    vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
	    vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
	    double  *r_mean_arr,

	    int     *delta_num_atompair_innuc_arr, 
	    double  *delta_num_atompair_innuc_mean_arr,  
	    double  *delta_pdf_atompair_innuc_arr,  

	    double  *delta_num_atompair_innuc_reduct_arr, 
	    double  *delta_num_atompair_innuc_mean_reduct_arr,  
	    double  *delta_pdf_atompair_innuc_reduct_arr,  

	    double  *volume_bin_pdf_arr,
	    double   density_nuc_01, 
	    double   boxsize,
	    int      num_bin_pdf
		);




    void Calculate_Delta_PDF( 
	    vector< CLHEP::Hep3Vector > coord_atom_00_innuc_vec, 
	    vector< CLHEP::Hep3Vector > coord_atom_01_innuc_vec, 
	    int index_nuc_00_inbox,
	    int index_nuc_01_inbox,
	    vector< int >             index_nuc_moved_inbox_vec,
	    vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
	    vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
	    double  *r_mean_arr,
	    int     *delta_num_atompair_innuc_arr, 
	    double  *delta_num_atompair_innuc_mean_arr,  
	    double  *delta_pdf_atompair_innuc_arr,  
	    double  *volume_bin_pdf_arr,
	    double   density_nuc_01, 
	    double   boxsize,
	    int      num_bin_pdf
	    );


    void Calculate_NR( 
	    vector< CLHEP::Hep3Vector > coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector > coord_atom_01_vec, 
	    vector< int > index_mol_atom_00_vec, 
	    vector< int > index_mol_atom_01_vec, 
	    double  *r_mean_pot_arr,
	    int     *num_atompair_inepsr_arr, 
	    double   boxsize,
	    int      num_bin_pot,
	    double   binsize_pot,
	    double   r_cut_pot  // this value is useless !!!
	    );

    void Calculate_NR_ForPDF( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    vector< int >                  index_mol_atom_00_vec, 
	    vector< int >                  index_mol_atom_01_vec, 
	    double                        *r_mean_pot_arr,
	    int                           *num_atompair_inepsr_arr, 
	    double                         boxsize,
	    int                            num_bin_pot,
	    double                         binsize_pot,
	    double                         r_cut_pot  // this value is useless !!!
	    );

    void Calculate_Delta_NR_New( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    vector< int >                  index_mol_atom_00_vec, 
	    vector< int >                  index_mol_atom_01_vec, 
	    bool                      *    is_moved_atom_inatomtype_00_arr, 
	    bool                      *    is_moved_atom_inatomtype_01_arr, 
	    CLHEP::Hep3Vector         * delta_coord_atom_inatomtype_00_arr,  
	    CLHEP::Hep3Vector         * delta_coord_atom_inatomtype_01_arr,  
	    int                           *delta_num_atompair_inepsr_arr, 
	    double                         boxsize,
	    int                            num_bin_pot,
	    double                         binsize_pot,
	    double                         r_cut_pot  // this value is useless !!!
	    );

    //==============================================================
    bool  Calculate_Delta_NR( 
	    vector< CLHEP::Hep3Vector > coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector > coord_atom_01_vec, 
	    vector< int > index_mol_atom_00_vec, 
	    vector< int > index_mol_atom_01_vec, 
	    int           index_atomtype_00_inbox,
	    int           index_atomtype_01_inbox,
	    vector< int >             index_atomtype_movedatomtype_inbox_vec,
	    vector< vector< int > >   index_atom_inatomtype_movedatom_inmovedatomtype_inbox_vec_2d,
	    vector< vector< CLHEP::Hep3Vector > >  delta_coord_movedatom_inmovedatomtype_inbox_vec_2d,
	    int     *delta_num_atompair_inepsr_arr, 
	    double   boxsize,
	    int      num_bin_pot,
	    double   binsize_pot,
	    double   r_cut_pot  // this value is useless !!!
	    );


    void    Calculate_NR_BasicSample( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    int                            index_atomtype_00_inbox,
	    int                            index_atomtype_01_inbox,
	    vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d,
	    vector< int >   num_nuc_sample_vec,
	    int      num_sample_exp,
	    double  *r_mean_arr,
	    int     *num_atompair_innuc_arr, 
	    int   ***num_nucpair_innuc_inbox_sample_arr_3d, 
	    double   boxsize,
	    int      num_bin_pdf,
	    double   binsize_pdf_sim
	    );


    void    Calculate_Delta_NR_BasicSample( 
	    vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
	    vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
	    int                            index_atomtype_00_inbox,
	    int                            index_atomtype_01_inbox,
	    vector< int >             index_nuc_moved_inbox_vec,
	    vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
	    vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
	    vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d,
	    vector< int >   num_nuc_sample_vec,
	    int      num_sample_exp,
	    double  *r_mean_arr,
	    int     *delta_num_atompair_innuc_arr, 
	    int   ***delta_num_nucpair_innuc_inbox_sample_arr_3d, 
	    double   boxsize,
	    int      num_bin_pdf,
	    double   binsize_pdf_sim
	    );



    void    Calculate_PDF_NSF_FromNR(
	    int     *num_nucpair_arr,
	    double  *num_nucpair_mean_arr,
	    double  *pdf_nucpair_arr,  
	    double  *r_mean_arr,
	    double   binsize_pdf, 
	    int      num_bin_pdf,
	    double  *volume_bin_pdf_arr,
	    int      num_atom_nuc_00,
	    double   density_nuc_01,

	    double  *nsf_nucpair_arr,  
	    double  *q_mean_arr,
	    int      num_bin_nsf,

	    double   ccbb, 
	    double   factor_nsf,
	    double   pi_rho_4
	    );


    void    Calculate_PSF_FromPDF(
	    double  *pdf_nucpair_arr,  
	    double  *r_mean_arr,
	    double   binsize_pdf, 
	    int      num_bin_pdf_sim,

	    double  *psf_nucpair_arr,  
	    double  *q_mean_arr,
	    int      num_bin_psf,

	    double   pi_rho_4
	    );

} // End namespace NDA_FUNC

#endif 
