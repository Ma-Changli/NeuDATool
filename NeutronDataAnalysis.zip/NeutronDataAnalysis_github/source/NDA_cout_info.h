cout<<"\033[40;31m"<<"  File name : "<<__FILE__<<" in function: "<<__func__<< "()" 
<<" at line : "<<__LINE__<<" at "<<__TIME__<<" on "<<__DATE__<<endl<<"\033[0m";
