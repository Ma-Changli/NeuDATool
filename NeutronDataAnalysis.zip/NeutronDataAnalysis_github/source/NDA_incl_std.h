// Standard C++ head files
#ifndef NDA_INCL_STD_H
#define NDA_INCL_STD_H  1

#include <iostream>
#include <iomanip>
#include <pthread.h>
#include <cstdio>
#include <fstream>
#include <cfloat>
#include <cstdlib>
#include <math.h>
#include <string>
#include <vector>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <stdlib.h>
#include <ctime> 

#endif 
