//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

//cuda __global__ function

#ifndef NDA_FUNC_GPU_MAIN_H
#define NDA_FUNC_GPU_MAIN_H  1


__global__ void Fill_Delta_NR(
	int       index_mol_atom_00,
	int      *index_mol_atom_01_arr,
	double      * coord_atom_00_arr,
	double      * coord_atom_01_arr,
	int         *  num_atompair_arr,
	int       num_bin,
	int       num_atom_01,
	double    boxsize,
	double    boxsize_div_2,
	double    binsize
	)
{
    int index = threadIdx.x + blockIdx.x * blockDim.x;

    if(index >= num_atom_01) return;

    if( index_mol_atom_00 == index_mol_atom_01_arr[index] ) return;

    int index_arr = index * 3;
    {
	double dist_x_pre = coord_atom_00_arr[0] - coord_atom_01_arr[index_arr];
	double dist_y_pre = coord_atom_00_arr[1] - coord_atom_01_arr[index_arr + 1];
	double dist_z_pre = coord_atom_00_arr[2] - coord_atom_01_arr[index_arr + 2];

	if(fabs(dist_x_pre) >= boxsize_div_2) dist_x_pre = (boxsize - fabs(dist_x_pre));
	if(fabs(dist_y_pre) >= boxsize_div_2) dist_y_pre = (boxsize - fabs(dist_y_pre));
	if(fabs(dist_z_pre) >= boxsize_div_2) dist_z_pre = (boxsize - fabs(dist_z_pre));

	double	dist_xyz_pre = sqrt(dist_x_pre * dist_x_pre  +  dist_y_pre * dist_y_pre + dist_z_pre * dist_z_pre);

	int index_bin_pre = floor( dist_xyz_pre/binsize );

	if(index_bin_pre < num_bin) atomicAdd( &num_atompair_arr[index_bin_pre], -1);
    }

    {
	double dist_x_new = coord_atom_00_arr[3] - coord_atom_01_arr[index_arr];
	double dist_y_new = coord_atom_00_arr[4] - coord_atom_01_arr[index_arr + 1];
	double dist_z_new = coord_atom_00_arr[5] - coord_atom_01_arr[index_arr + 2];

	if(fabs(dist_x_new) >= boxsize_div_2) dist_x_new = (boxsize - fabs(dist_x_new));
	if(fabs(dist_y_new) >= boxsize_div_2) dist_y_new = (boxsize - fabs(dist_y_new));
	if(fabs(dist_z_new) >= boxsize_div_2) dist_z_new = (boxsize - fabs(dist_z_new));

	double	dist_xyz_new = sqrt(dist_x_new * dist_x_new  +  dist_y_new * dist_y_new + dist_z_new * dist_z_new);

	int index_bin_new = floor( dist_xyz_new/binsize );

	if(index_bin_new < num_bin) atomicAdd( &num_atompair_arr[index_bin_new], 1);
    }

    return;

}


__global__ void Fill_Delta_NR_AllMov(
	double      * coord_atom_00_arr,
	double      * coord_atom_01_arr,
	int         *  num_atompair_arr,
	int       num_bin,
	double    boxsize,
	double    boxsize_div_2,
	double    binsize
	)
{
    int index = threadIdx.x + blockIdx.x * blockDim.x;

    // all moved  
    if(index == 0) 
    {

	{
	    double dist_x_pre = coord_atom_00_arr[0] - coord_atom_01_arr[0];
	    double dist_y_pre = coord_atom_00_arr[1] - coord_atom_01_arr[1];
	    double dist_z_pre = coord_atom_00_arr[2] - coord_atom_01_arr[2];

	    if(fabs(dist_x_pre) >= boxsize_div_2) dist_x_pre = (boxsize - fabs(dist_x_pre));
	    if(fabs(dist_y_pre) >= boxsize_div_2) dist_y_pre = (boxsize - fabs(dist_y_pre));
	    if(fabs(dist_z_pre) >= boxsize_div_2) dist_z_pre = (boxsize - fabs(dist_z_pre));

	    double dist_xyz_pre = sqrt(dist_x_pre * dist_x_pre  +  dist_y_pre * dist_y_pre + dist_z_pre * dist_z_pre);

	    int index_bin_pre = floor( dist_xyz_pre/binsize );

	    if(index_bin_pre < num_bin) atomicAdd( &num_atompair_arr[index_bin_pre], -1);
	}

	{
	    double dist_x_new = coord_atom_00_arr[3] - coord_atom_01_arr[3];
	    double dist_y_new = coord_atom_00_arr[4] - coord_atom_01_arr[4];
	    double dist_z_new = coord_atom_00_arr[5] - coord_atom_01_arr[5];

	    if(fabs(dist_x_new) >= boxsize_div_2) dist_x_new = (boxsize - fabs(dist_x_new));
	    if(fabs(dist_y_new) >= boxsize_div_2) dist_y_new = (boxsize - fabs(dist_y_new));
	    if(fabs(dist_z_new) >= boxsize_div_2) dist_z_new = (boxsize - fabs(dist_z_new));

	    double	dist_xyz_new = sqrt(dist_x_new * dist_x_new  +  dist_y_new * dist_y_new + dist_z_new * dist_z_new);

	    int index_bin_new = floor( dist_xyz_new/binsize );

	    if(index_bin_new < num_bin) atomicAdd( &num_atompair_arr[index_bin_new], 1);
	}
    }


    // 00 moved  
    if(index == 1) 
	for(int i_add_sub = 0; i_add_sub < 2; i_add_sub++)
	{

	    double dist_x_pre = coord_atom_00_arr[0] - coord_atom_01_arr[0];
	    double dist_y_pre = coord_atom_00_arr[1] - coord_atom_01_arr[1];
	    double dist_z_pre = coord_atom_00_arr[2] - coord_atom_01_arr[2];

	    if(fabs(dist_x_pre) >= boxsize_div_2) dist_x_pre = (boxsize - fabs(dist_x_pre));
	    if(fabs(dist_y_pre) >= boxsize_div_2) dist_y_pre = (boxsize - fabs(dist_y_pre));
	    if(fabs(dist_z_pre) >= boxsize_div_2) dist_z_pre = (boxsize - fabs(dist_z_pre));

	    double	dist_xyz_pre = sqrt(dist_x_pre * dist_x_pre  +  dist_y_pre * dist_y_pre + dist_z_pre * dist_z_pre);

	    int index_bin_pre = floor( dist_xyz_pre/binsize );

	    if(index_bin_pre < num_bin) atomicAdd( &num_atompair_arr[index_bin_pre], 1);

	    double dist_x_new = coord_atom_00_arr[3] - coord_atom_01_arr[0];
	    double dist_y_new = coord_atom_00_arr[4] - coord_atom_01_arr[1];
	    double dist_z_new = coord_atom_00_arr[5] - coord_atom_01_arr[2];

	    if(fabs(dist_x_new) >= boxsize_div_2) dist_x_new = (boxsize - fabs(dist_x_new));
	    if(fabs(dist_y_new) >= boxsize_div_2) dist_y_new = (boxsize - fabs(dist_y_new));
	    if(fabs(dist_z_new) >= boxsize_div_2) dist_z_new = (boxsize - fabs(dist_z_new));

	    double	dist_xyz_new = sqrt(dist_x_new * dist_x_new  +  dist_y_new * dist_y_new + dist_z_new * dist_z_new);

	    int index_bin_new = floor( dist_xyz_new/binsize );

	    if(index_bin_new < num_bin) atomicAdd( &num_atompair_arr[index_bin_new], -1);

	}


    // 01 moved  
    if(index == 2) 
	for(int i_add_sub = 0; i_add_sub < 2; i_add_sub++)
	{

	    {
		double dist_x_pre = coord_atom_00_arr[0] - coord_atom_01_arr[0];
		double dist_y_pre = coord_atom_00_arr[1] - coord_atom_01_arr[1];
		double dist_z_pre = coord_atom_00_arr[2] - coord_atom_01_arr[2];

		if(fabs(dist_x_pre) >= boxsize_div_2) dist_x_pre = (boxsize - fabs(dist_x_pre));
		if(fabs(dist_y_pre) >= boxsize_div_2) dist_y_pre = (boxsize - fabs(dist_y_pre));
		if(fabs(dist_z_pre) >= boxsize_div_2) dist_z_pre = (boxsize - fabs(dist_z_pre));

		double	dist_xyz_pre = sqrt(dist_x_pre * dist_x_pre  +  dist_y_pre * dist_y_pre + dist_z_pre * dist_z_pre);

		int index_bin_pre = floor( dist_xyz_pre/binsize );

		if(index_bin_pre < num_bin) atomicAdd( &num_atompair_arr[index_bin_pre], 1);
	    }
	    double dist_x_new = coord_atom_00_arr[0] - coord_atom_01_arr[3];
	    double dist_y_new = coord_atom_00_arr[1] - coord_atom_01_arr[4];
	    double dist_z_new = coord_atom_00_arr[2] - coord_atom_01_arr[5];

	    if(fabs(dist_x_new) >= boxsize_div_2) dist_x_new = (boxsize - fabs(dist_x_new));
	    if(fabs(dist_y_new) >= boxsize_div_2) dist_y_new = (boxsize - fabs(dist_y_new));
	    if(fabs(dist_z_new) >= boxsize_div_2) dist_z_new = (boxsize - fabs(dist_z_new));

	    double	dist_xyz_new = sqrt(dist_x_new * dist_x_new  +  dist_y_new * dist_y_new + dist_z_new * dist_z_new);

	    int index_bin_new = floor( dist_xyz_new/binsize );

	    if(index_bin_new < num_bin) atomicAdd( &num_atompair_arr[index_bin_new], -1);

	}

    return;
}


   //=============================================================================================
   //=============================================================================================

   //add array b*scale to array a, array will be changed.
   __global__ void  Add_Array_To1_Double_kernel(double *a, double *b, double scale, int num_bin)
   {
       int index = threadIdx.x + blockIdx.x * blockDim.x;
       if(index < num_bin)  a[index] += b[index] * scale;
   }
   
   //calculate the chisquare (X^2) of 2 different arrays (without errors). 
   __global__ void  Cal_Chisq_2Array_Double_kernel( double * arr_00, double * arr_01, int num_bin, 
   	double * arr_x, int num_bin_min, int num_bin_max, double * chisq)
   {
       int index = threadIdx.x + blockIdx.x * blockDim.x;
       if(index >= num_bin_min && index < num_bin_max )
       {
   	double chisq_local = (arr_00[index] - arr_01[index]) * (arr_00[index] - arr_01[index]);
   	atomicAdd( & chisq[0], chisq_local);
       }
   }

#endif
