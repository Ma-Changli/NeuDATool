//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_MOLE_O_SIO2_H
#define NDA_MOLE_O_SIO2_H  1

#include "NDA_molecule.h"

class NDA_mole_o_sio2 : public NDA_molecule {

    friend class NDA_atom;

    public:
    NDA_mole_o_sio2(){};
    ~NDA_mole_o_sio2(){};

    void  Initialize(bool set_coord);

    void   CalculateEnergyMol();
    void   CalculateEnergyMol_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);
    void   CalculateEnergyMol_Temp(CLHEP::Hep3Vector delta_coord_atom);

};

#endif 

