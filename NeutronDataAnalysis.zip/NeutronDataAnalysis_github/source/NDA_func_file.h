//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_FILE_H
#define NDA_FUNC_FILE_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_FILE {

    void Write_NSF_Data(
	    string name_file,  
	    vector< nsf_struct >   q_nsf_data_vec, 
	    bool have_err
	    );

    void Write_NSF_Data(
	    string name_file,  
	    vector< double >   nsf_data_vec, 
	    vector< double >   q_data_vec, 
	    bool have_err
	    );

    void Write_NSF_Data_Arr(
	    string       name_file,  
	    double *     val_q_arr, 
	    double *   val_nsf_arr, 
	    int            num_bin
	    );

    void Write_2Array_AsXY(
	    string       name_file,  
	    double *     val_x_arr, 
	    double *     val_y_arr, 
	    int            num_bin
	    );

    void Write_2Array_AsXY_NormTo1(
	    string       name_file,  
	    double *     val_x_arr, 
	    double *     val_y_arr, 
	    int            num_bin
	    );


    void Write_2Array_AsXY(
	    string       name_file,  
	    double *     val_x_arr, 
	    int    *     val_y_arr, 
	    int            num_bin
	    );


    void Write_2Array_AsXY(
	    string       name_file,  
	    double *     val_x_arr, 
	    long    *     val_y_arr, 
	    int            num_bin
	    );

void Write_2Array_AsXY(
	    string       name_file,  
	    double *     val_x_arr, 
	   unsigned  long  long int  *     val_y_arr, 
	    int            num_bin
	    );



  void Write_2Vec_AsXY(
            string       name_file,
            vector< double >   column_00_vec,
            vector< double >   column_01_vec,
            int                num_line
            );


    void Read_NSF_Data_QNSF(
	    string name_file_input,
	    vector< double > & q_mean_data_vec, 
	    vector< double > &    nsf_data_vec,
	    int & num_bin_nsf,
	    double val_q_min_sim,
	    double val_q_max_sim
	    );


    void Read_NSF_Data_Mint01(
	    string name_file_input,
	    vector< double > & q_mean_data_vec, 
	    vector< double > &    nsf_data_vec,
	    int & num_bin_nsf,
	    double val_q_min_sim,
	    double val_q_max_sim
	    );




    void Read_File_2Column_Vec_Double(
	    string name_file_input,
	    vector< double > &  column_00_vec,
	    vector< double > &  column_01_vec,
	    int              &  num_line
	    );


    void Read_NSF_Data_Debyer_02(
	    string name_file_input,
	    vector< double > & q_mean_data_vec, 
	    vector< double > &    nsf_data_vec,
	    double boxsize
	    );



    void  PrintNSFToFile(
	    std::string  name_dir, 
	    std::string  name_file,
	    double      *q_mean_arr,
	    double      *nsf_total_inbox_arr,
	    int          num_bin_nsf
	    );


    void  ReadAtomMOlFrameSampleGro(
	    string         name_file,  
	    vector<string> name_mol_vec,
	    int            num_atom_frame, 
	    vector< vector< vector< atom_struct > > > & atom_mol_frame_sample_vec_3d, 
	    // the atoms are classified in --> sample : frame : molecule : atom 
	    vector< vector< vector< atom_struct > > > & atom_mol_moltype_sample_vec_3d, 
	    // the atoms are classified in --> sample : molecule : atom 
	    vector< CLHEP::Hep3Vector >               & boxsize_frame_sample_vec, 
	    vector< double >                          & time_sample_vec 
	    ); 

 void  ReadAtomMOlFrameSampleGro(
	    string         name_file,  
	    vector<string> name_mol_vec,
	    int            num_atom_frame, 
	    vector< vector< vector< atom_struct > > > & atom_mol_frame_sample_vec_3d, 
	    // the atoms are classified in --> sample : frame : molecule : atom 
	    vector< vector< vector< atom_struct > > > & atom_mol_moltype_sample_vec_3d, 
	    // the atoms are classified in --> sample : molecule : atom 
	    vector< vector< CLHEP::Hep3Vector > > & coord_mol_frame_sample_vec_2d, 
	    vector< vector< CLHEP::Hep3Vector > > & coord_mol_moltype_sample_vec_2d, 

	    vector< CLHEP::Hep3Vector >               & boxsize_frame_sample_vec, 
	    vector< double >                          & time_sample_vec 
	    ); 




} // End namespace NDA_FUNC

#endif 
