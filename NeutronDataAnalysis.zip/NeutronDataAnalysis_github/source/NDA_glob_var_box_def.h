#ifndef NDA_GLOB_VAR_BOX_DEF_H
#define NDA_GLOB_VAR_BOX_DEF_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"
#include "NDA_symbox_h2o.h"
#include "NDA_symbox_h2o_jmol.h"
#include "NDA_symbox_ethanol_jmol.h"
#include "NDA_symbox_ethanol_80.h"
#include "NDA_symbox_dmso_90.h"
#include "NDA_symbox_dmso_90_mdbox.h"
#include "NDA_symbox_dmso_90_mdmol.h"
#include "NDA_symbox_dmso_50_mdmol.h"

#include "NDA_symbox_dmso_60_mdmol.h"
#include "NDA_symbox_dmso_70_mdmol.h"
#include "NDA_symbox_dmso_80_mdmol.h"


#include "NDA_symbox_pdea_80.h"
#include "NDA_symbox_sio2.h"

//==================================================
//Variable if simulation box and data

// Using Gromacs Simlation data or experiment data 
// Only it is useful when test the program with H2O neutron scattering data
bool    is_read_simu_or_isis;

int           num_sample_exp;  // The experiment data file amount

vector< string >      name_sample_exp_vec;
vector< string >      name_file_data_exp_vec;

vector< vector < int > >    index_sample_inprocs_vec;
vector< int >               index_procs_sample_vec;

int num_sample_in_thisprocs;

//// Simulation box
//NDA_symbox              sim_box_basic_single;
//NDA_symbox              sim_box_sample_single;
//vector< NDA_symbox >    sim_box_sample_vec; 

// Simulation box
NDA_symbox *             sim_box_basic_single;
NDA_symbox *             sim_box_sample_single;
vector< NDA_symbox_h2o >    sim_box_sample_vec; 

int    num_mol_inbox_input;

double           boxsize      ;
double           boxsize_div_2;
double        volume_box      ;
double       num_dens_atom_tot;
double  num_atom_inbox_sq     ;

CLHEP::Hep3Vector  boxsize_3vector;

std::map<string,  double> b_nuc_map;

int  num_nuc_inbox_sample_single;

vector< int >  num_nuc_sample_vec;

vector< int >  num_nucpair_inbox_sample_vec;

int      num_nuc_sample_max;
int  num_nucpair_sample_max;

int  num_atom_inbox;

// Users can initialize simulation box directly by initialize function in NDA_symbox class
int  num_mol_inbox;

int num_atom_inmol_inbox_max;  // Set the maximal  atom number of all molecules. In H2O, the number is 3 or larger than 3.  

string name_mol;
double wt_mol  ; // g/mol
double density ; // g/cm^3


vector<CLHEP::Hep3Vector >       coord_atom_inbox_inbox_vec;
vector<CLHEP::Hep3Vector >       coord_atom_inmol_inbox_vec;
vector<CLHEP::Hep3Vector >    coord_mol_com_inbox_inbox_vec;
vector<std::string >          name_nuc_atom_inbox_inbox_vec;

double *          coord_mol_com_inbox_inbox_arr;
double *             coord_atom_inbox_inbox_arr;
double *             coord_atom_inmol_inbox_arr;
char   *          name_nuc_atom_inbox_inbox_arr; // 4 character is enough
int    * num_char_name_nuc_atom_inbox_inbox_arr;

string           name_nuc;
int     num_char_name_nuc;

int  num_atomtype_inbox;
int  num_atompair_inbox;

long     *num_atom_inatomtype_inbox_arr;
double   *density_atomtype_arr         ;

double  *         cc_atompair_arr;
double  * factor_nsf_atompair_arr;

int index_atompair;

string name_atomtype;
vector< string > name_atomtype_inbox_vec;
vector< double > num_atom_atomtype_inbox_vec;

vector< vector < int > > index_atompair_inprocs_vec;
vector< int >  index_procs_atompair_vec;
int   num_atompair_in_thisprocs;
vector< string > name_atompair_inbox_vec;



//==================
long     ** num_atom_innuctype_sample_arr_2d;
double   **    density_nuctype_sample_arr_2d;

double   **       cbb_nuc_sample_arr_2d; 
double   *    cbb_nuc_tot_sample_arr; 

double   *    cbb_bkgd_sample_arr; 


int num_nuc_sample_single;


#endif 
