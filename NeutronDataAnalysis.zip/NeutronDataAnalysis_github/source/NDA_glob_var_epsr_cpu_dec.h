extern  bool     have_q_pot_cut;

extern  double        q_pot_min;
extern  double        q_pot_max;
extern  int     num_bin_qqq_fit;

extern  double chisq_fit_nsf_max;

// Move molecule randomly  
//==========================================================================
extern  int        index_mov_mol;
extern  int        index_mov_atom;

extern  bool       is_mov_mol ;
extern  bool       is_mov_atom;

extern  double     energy_mol_pre;
extern  double     energy_mol_new;
extern  double     exponent_factor;

extern  bool       is_trans_or_rot;   //If it is  translation, the value is true

// in moved atom order
extern  vector< int >                        index_atomtype_movedatom_inbox_vec;
extern  vector< int >                 index_atom_inatomtype_movedatom_inbox_vec;
extern  vector< CLHEP::Hep3Vector >             delta_coord_movedatom_inbox_vec;

// in moved atomtype order
extern  vector< int >                                                 index_atomtype_movedatomtype_inbox_vec;
extern  vector< vector< int > >                 index_atom_inatomtype_movedatom_inmovedatomtype_inbox_vec_2d;
extern  vector< vector< CLHEP::Hep3Vector > >             delta_coord_movedatom_inmovedatomtype_inbox_vec_2d;

extern  double  x_trans;
extern  double  y_trans;
extern  double  z_trans;
extern  CLHEP::Hep3Vector  xyz_trans; 
extern  CLHEP::Hep3Vector  delta_coord_atom_moved; 

extern  double x_axis;
extern  double y_axis;
extern  double z_axis;
extern  CLHEP::Hep3Vector  axis_rot; 
extern  double angle_rot;

extern  double    *delta_coord_arom_moved_arr;

extern  double          pot_inbox_pre;
extern  double          pot_inbox_new;
extern  double    delta_pot_inbox;

extern  vector< double >  pot_inbox_vec;

extern  bool is_move_accepted;

extern  long     i_move_molatom    ;
extern  long     i_move_molatom_try;

extern  long     i_move_molatom_samepot    ;
extern  long     i_move_molatom_samepot_try;
extern  long     i_move_molatom_samepot_try_real;
extern  long     num_move_molatom_samepot_max;
extern  int                factor_move_mole;

extern  double   accept_ratio_move_pre;
extern  double   accept_ratio_move_new;
extern  double   accept_ratio_move_diff;

extern  double   ratio_emp_vs_ref;

extern  bool     have_delta_nr;

extern  bool     begin_move_atom;

extern  int      num_atom_moved;

extern  bool     should_update_pot;
extern  bool     have_update_pot; 
extern  int      index_update_pot; 

extern  double  * chisq_nsf_epsr_pre_arr    ;
extern  double  * chisq_nsf_epsr_new_arr    ;

extern  double  * chisq_nsf_rmc_pre_arr ;
extern  double  * chisq_nsf_rmc_new_arr ;

extern  double  chisq_nsf_rmc_pre;
extern  double  chisq_nsf_rmc_new;

extern  double    chisq_nsf_uplimit;

  
extern  bool    is_epsr_equilibrium;


extern  string          name_file_chisq_nsf_str;
extern  ofstream      output_file_chisq_nsf;

// Whether  accumulate data after EPMC reachs equilibrium
extern  bool    is_accumulate_data;
//  is_accumulate_data  = true;

extern  int   i_sum_nsf    ;
extern  int num_sum_nsf_max;


extern  string          name_file_sum_nsf_str;
extern  ofstream      output_file_sum_nsf;

extern  bool is_continue_simu;

extern  int *  have_delta_nr_arr; 
