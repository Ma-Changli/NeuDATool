//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_MOLECULE_H
#define NDA_MOLECULE_H  1

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include  "CLHEP/Vector/ThreeVector.h"
#include "NDA_atom.h"
#include "atomtables.h"

#include <vector>

typedef std::vector<NDA_atom> Vatom;

using namespace std;
using namespace CLHEP;


class NDA_molecule {
    friend class NDA_atom;

    public:
    NDA_molecule(){};
    ~NDA_molecule(){};

    virtual  void  Initialize(bool is_set_coord) = 0;
    //    virtual  void  Initialize_Sample(string name_sample, bool set_nuc_name) = 0;

    void  Initialize_ByJmolFile(string name_file_jmol_str, string name_mol,  int & num_atom_inmol);
    void  Initialize_ByGroFile (string name_file_jmol_str, string name_mol,  int & num_atom_inmol);

    inline void   SetNameMol(std::string name_input){ name_mol = name_input;} 
    inline string GetNameMol(){return name_mol;}

    inline void   SetEnergyMol(double energy_input){energy_mol = energy_input;} 
    inline double GetEnergyMol(){return energy_mol;}

    inline void   SetEnergyMolTemp(double energy_input){energy_mol_temp = energy_input;} 
    inline double GetEnergyMolTemp(){return energy_mol_temp;}

    inline Vatom & GetAtomInMolVec(){ return atom_inmol_vec;}
    inline int     GetNumAtomInMol(){ return num_atom_inmol;}
    // ....  .....  .....  .....  .....  .....  .....  .....  .....  .....  .....  .....  .....  .....  .....

    inline    void  SetCoordMolComInBox(CLHEP::Hep3Vector  coord_mol_com_inbox_input,  double boxsize) 
    { 
	coord_mol_com_inbox = coord_mol_com_inbox_input; 

	if(coord_mol_com_inbox[0] > boxsize)  coord_mol_com_inbox[0] -= boxsize;
	if(coord_mol_com_inbox[1] > boxsize)  coord_mol_com_inbox[1] -= boxsize;
	if(coord_mol_com_inbox[2] > boxsize)  coord_mol_com_inbox[2] -= boxsize;

	if(coord_mol_com_inbox[0] < 0.0)  coord_mol_com_inbox[0] -= boxsize;
	if(coord_mol_com_inbox[1] < 0.0)  coord_mol_com_inbox[1] -= boxsize;
	if(coord_mol_com_inbox[2] < 0.0)  coord_mol_com_inbox[2] -= boxsize;

    }

    inline    CLHEP::Hep3Vector    GetCoordMolComInBox() { return coord_mol_com_inbox; }

    //==========================
    void  Translation(CLHEP::Hep3Vector xyz_delta, double boxsize);
    void  Rotate(CLHEP::Hep3Vector & axis, double delta, double boxsize);

    void  TranslationAttempt(CLHEP::Hep3Vector xyz_delta, double boxsize);
    void  RotateAttempt(CLHEP::Hep3Vector & axis, double delta, double boxsize);

    void  ConfirmAtomMove(bool is_rotate);

    //==========================
    void  TranslationSingleAtom(int index_atom, CLHEP::Hep3Vector xyz_delta, double boxsize);
    void  RotateSingleAtom(int index_atom, CLHEP::Hep3Vector & axis, double delta, double boxsize);

    void  TranslationAttemptSingleAtom(int index_atom, CLHEP::Hep3Vector xyz_delta, double boxsize);
    void  RotateAttemptSingleAtom(int index_atom, CLHEP::Hep3Vector & axis, double delta, double boxsize);

    void  ConfirmAtomMoveSingleAtom(int index_atom, bool is_rotate);

    inline void  UpdateEnergyMol() { energy_mol = energy_mol_temp; }

    //    virtual  void   CalculateEnergyMol();
    //    virtual  void   CalculateEnergyMol_H2O();
    //    virtual  void   CalculateEnergyMol_H2O_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);
    //
    //    virtual  void   CalculateEnergyMol_Harm();
    //    virtual  void   CalculateEnergyMol_Harm_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);
    //    virtual  void   CalculateEnergyMol_Harm_Temp(CLHEP::Hep3Vector delta_coord_atom);


    virtual  void   CalculateEnergyMol() = 0;
    virtual  void   CalculateEnergyMol_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom) = 0;
    virtual  void   CalculateEnergyMol_Temp(CLHEP::Hep3Vector delta_coord_atom) = 0;


    void   Print();

    //  private:
    protected:  // For subclass 

    std::string name_mol;
    Vatom  atom_inmol_vec;
    int    num_atom_inmol;

    CLHEP::Hep3Vector coord_mol_com_inbox; 

    double energy_mol; 
    double energy_mol_temp; 

    double    k_bond;
    double mean_bond;

    double    k_angle;
    double mean_angle;

    vector< double > bond_length_mol_vec;
    vector< double > w_sq_bond_mol_vec;
    bool have_move_spec;
    int  num_move_spec; // spec means special 
    vector< int >  index_move_spec_vec;

};


#endif 

