//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_ARRAY_CU_H
#define NDA_FUNC_ARRAY_CU_H  1

namespace NDA_FUNC_ARRAY_GPU{

    extern "C" {
	void Multiply_Array_Int(
		int     * arr_00,
		int       factor,
		int      num_bin
		);

	double Multiply_2Array_to_1Scalar(
		double    *arr_00,
		int    num_bin_00, 
		int       *arr_01,  
		int    num_bin_01
		);

    }

} // End namespace NDA_FUNC
#endif 
