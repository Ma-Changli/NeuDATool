//double boxsize_div_2;

int    ** delta_num_atompair_inepsr_gpu_arr_2d_h; 
int    ** delta_num_atompair_inepsr_gpu_arr_2d ;

int    num_atom;
int    memsize;
int    memsize_cpu;
int    memsize_gpu;

int *	num_block_arr;

int ** index_mol_atom_cpu_arr_2d  ; 
int ** index_mol_atom_gpu_arr_2d_h; 
int ** index_mol_atom_gpu_arr_2d; 


double ** coord_xyz_cpu_arr_2d  ;
double ** coord_xyz_gpu_arr_2d_h; 
double ** coord_xyz_gpu_arr_2d; 


double * coord_xyz_00_cpu;  // The first is old, and the second is new
double * coord_xyz_01_cpu;  // The first is old, and the second is new

double * coord_xyz_00_gpu; 
double * coord_xyz_01_gpu; 

double    ** val_nsf_diff_fit_gpu_arr_2d_h ; 
double    ** val_nsf_diff_fit_gpu_arr_2d;
double    ** val_nsf_diff_gpu_arr_2d_h    ; 
double    ** val_nsf_diff_gpu_arr_2d;

double  **  pot_poisson_emp_rad_gpu_arr_2d_h;
double  **  pot_poisson_emp_qqq_gpu_arr_2d_h;
double  **  pot_poisson_emp_rad_gpu_arr_2d;
double  **  pot_poisson_emp_qqq_gpu_arr_2d;

double *  chisq_fit_q_pot_cpu_arr;
double *  chisq_fit_q_pot_gpu_arr;



