//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_POT_H
#define NDA_FUNC_POT_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"

using namespace std;
using namespace CLHEP;


namespace NDA_FUNC_POT {

    void  Calculate_Pot_Table(
	    string           name_pottype,
	    int              index_atomtype_00,
	    int              index_atomtype_01,
	    vector<string>   name_atomtype_vec, 
	    double         **parameter_pot_atomtype_2d_arr, 
	    double          *pot_arry, 
	    double          *r_mean_arr,
	    int              num_bin_pot
	    );



    typedef void (*func_pot) (
	    double   *parameter_pot_atomtype_00,
	    double   *parameter_pot_atomtype_01,
	    bool      is_same_atomtype,
	    double   *r_mean_arr,
	    double   *pot_atompair_inatomtype_arr,  
	    int       num_bin_pot
	    );


    void Gen_Pot_Table_LJ( 
	    double   *parameter_pot_atomtype_00,
	    double   *parameter_pot_atomtype_01,
	    bool      is_same_atomtype,
	    double   *r_mean_arr,
	    double   *pot_atompair_inatomtype_arr,  
	    int       num_bin_pot
	    );

    void Gen_Pot_Table_EP( 
	    double   *parameter_pot_atomtype_00,
	    double   *parameter_pot_atomtype_01,
	    bool      is_same_atomtype,
	    double   *r_mean_arr,
	    double   *pot_atompair_inatomtype_arr,  
	    int       num_bin_pot
	    );



    void Gen_Truncate_Table_Coulomb( 
	    double    sigma_c,
	    double   *r_mean_arr,
	    double   *truncate_table_arr,  
	    int       num_bin_pot
	    );



    void Gen_Truncate_Table_NonCoulomb( 
	    double    r_minpt,
	    double    r_maxpt,
	    double   *r_mean_arr,
	    double   *truncate_table_arr,  
	    int       num_bin_pot
	    );



    //============================
    void  Calculate_Pot_Table_Rep(
	    string           name_pottype,
	    double           c_min,
	    double           r_min,
	    double           sigma_rep,
	    double           g_lim,
	    double          *pot_arry, 
	    double          *r_mean_arr,
	    int              num_bin_pot
	    );



    typedef void (*func_pot_rep) (
	    double           c_min,
	    double           r_min,
	    double           sigma_rep,
	    double           g_lim,
	    double          *pot_arry, 
	    double          *r_mean_arr,
	    int              num_bin_pot
	    );


    void Gen_Pot_Table_Rep_Exp( 
	    double           c_min,
	    double           r_min,
	    double           sigma_rep,
	    double           g_lim,
	    double          *pot_arry, 
	    double          *r_mean_arr,
	    int              num_bin_pot
	    );



    void Gen_Pot_Table_Rep_Har( 
	    double           c_min,
	    double           r_min,
	    double           sigma_rep,
	    double           g_lim,
	    double          *pot_arry, 
	    double          *r_mean_arr,
	    int              num_bin_pot
	    );


    unsigned long factorial(unsigned int n);

//=============================================================
    void Gen_Pot_Table_EMP_Poisson_RScpace( 
	    double   *r_mean_arr,
	    double   *   pot_arr, 
	    int       num_bin_pot,
	    double    rho,
	    double    sigma,
	    double    r_peak       
	    );

    void Gen_Pot_Table_EMP_Poisson_RScpace_Stirling( 
	    double   *r_mean_arr,
	    double   *   pot_arr, 
	    int       num_bin_pot,
	    double    rho,
	    double    sigma,
	    double    r_peak       
	    );


    void Gen_Pot_Table_EMP_Poisson_QScpace( 
	    double   *q_mean_arr,
	    double   *   pot_arr, 
	    int       num_bin_q,
	    double    sigma,
	    double    r_peak       
	    );





} // End namespace NDA_FUNC

#endif 
