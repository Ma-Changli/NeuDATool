//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_MATRIX_H
#define NDA_FUNC_MATRIX_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

namespace NDA_FUNC_MATRIX 
{
    void Invert_Matrix_MN_MC(
	    double   **cwt, 
	    double   **cwtt, 
	    int        num_row, 
	    int        num_col, 
	    double  & fac_data,
	    string name_file_matrix
	    );

    void Milti_Matrix(
	    double **matrix_00, 
	    double **matrix_01, 
	    int      num_row, 
	    int      num_col, 
	    double **matrix_product);

    void Chisq_Matrix(
	    double **matrix, 
	    int      num_row_col, 
	    double & chisq);

    void Print_Matrix_2D( double **matrix_2d, int num_row, int num_col, string name_matrix);
    void Print_Matrix_2D_File(double **matrix_2d, int num_row, int num_col, string name_matrix, string name_file);
    void Print_Matrix_2D_File_New(double **matrix_2d, int num_row, int num_col, string name_matrix, string name_file);
    void Read_Matrix_2D_File_New(double **matrix_2d, int num_row, int num_col, string name_file);

    void Invert_Matrix_NN_MC(
	    double   **cwt, 
	    double   **cwtt, 
	    int        num_rowcol 
	    );
} 

#endif 
