#ifndef NDA_GLOB_VAR_RUN_DEC_H
#define NDA_GLOB_VAR_RUN_DEC_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"

//==================================================
//Variable of run configuration
extern  int    argc_glob;
extern  char**  argv_glob;
 
extern  clock_t time_start;
extern  clock_t time_finish;
 
extern  int  index_arr_local;
 
extern  stringstream    name_file_pot_ss;
extern  string          name_file_pot_str;
extern  ofstream      output_file_pot;
 
extern  stringstream    name_file_local_ss;
extern  string          name_file_local_str;
extern  ofstream      output_file_local;
extern  ofstream      output_file_local_01;
 
extern  stringstream    name_file_waste_ss;
extern  string          name_file_waste_str;
extern  ofstream      output_file_waste;
 
extern  ofstream      output_file_debug;

extern  string         result_directory;
extern  stringstream   stringstream_single;
 
extern  string   name_sample_chem_str;
extern  string     extension_file_gro;
extern  string     extension_file_pot;
extern  string     extension_file_pdf;
extern  string     extension_file_nsf;
 

// Delete old results file 
extern  string cmd_rm_str;
extern  string cmd_mkdir_str;
 
extern  int      num_char_procs;
extern  int      num_char_step ;
 
extern  int    num_procs;
extern  int    index_procs; 
extern  int    index_procs_root;
 
 
// Whether print debug information 
// is_print_debug_info = true;
extern  bool  is_print_debug_info; 
 
// Whether print intermediate result  
extern  bool   is_print_inter_result;
// Whether print emperical potential functions   
extern  bool   is_print_poisson_function;
 
extern  double temperature; // K 
 
//  double kT = CLHEP::k_Boltzmann * temperature;
extern  double kT; //kJ
extern  double inverse_kT;
 

 
#endif 
