//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_TEMP_H
#define NDA_FUNC_TEMP_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_TEMP {



    template <typename T>
	void Add_Arrys_2To1( T *arr_00,  T *arr_01,  T *arr_sum, int num_bin)
	{

	    for(int i_bin = 0; i_bin < num_bin; i_bin++)
	    {
		arr_sum[i_bin] = arr_00[i_bin] + arr_01[i_bin];
	    }

	}


    template <typename T>
	void Copy_Arrys_1To2( T *arr_source,  T *arr_target, int num_bin)
	{

	    for(int i_bin = 0; i_bin < num_bin; i_bin++)
	    {
		arr_target[i_bin] = arr_source[i_bin];
	    }

	}



//    template <typename T, typename W>
//	T Multiply_2Array_to_1Scalar(T *arr_00, int num_bin_00, W *arr_01,  int num_bin_01)
//	{
//	    int num_bin;
//
//	    if(num_bin_00 <= num_bin_01)  num_bin = num_bin_00;
//	    else                          num_bin = num_bin_01;
//
//	    T product = 0.0;
//
//	    for(int i_bin = 0; i_bin < num_bin; i_bin++)
//	    {
//		product += arr_00[i_bin] * arr_01[i_bin];
//	    }
//
//	    return product;
//
//	}



    template <typename T>
	T Accumulate_Array( T *arr,  int num_bin)
	{

	    T sum = 0.0;

	    for(int i_bin = 0; i_bin < num_bin; i_bin++)
	    {
		sum += arr[i_bin];
	    }

	    return sum;

	}




    template <typename T>
	void Subtract_2Arrys(T *arr_00,  T *arr_01,  T *arr_result, int num_bin)
	{

	    for(int i_bin = 0; i_bin < num_bin; i_bin++)
	    {
		arr_result[i_bin] = arr_00[i_bin] - arr_01[i_bin];
	    }

	}



} // End namespace NDA_FUNC

#endif 
