// This file contains the headerfile of the main program

// Select Parallel method 
// USE_MPI  USE_OMP  USE_GPU  are defined in the Makefile of this folder 

#ifndef NDA_HEADER_MAIN_H
#define NDA_HEADER_MAIN_H  1


#ifdef USE_GPU
#include "NDA_func_gpu_basic.h"
#include "NDA_func_gpu_main.h"
#endif

#ifdef USE_MPI
#include <mpi.h>
#endif

#ifdef USE_OMP
#include <omp.h>
#endif

// Standard C++ head files
#include <iostream>
#include <iomanip>
#include <pthread.h>
#include <cstdio>
#include <fstream>
#include <cfloat>
#include <cstdlib>
#include <math.h>
#include <string>
#include <vector>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <cstdio>
#include <stdlib.h>
#include <ctime> 

using namespace std;

// CLHEP - A Class Library for High Energy Physics  
// http://proj-clhep.web.cern.ch/proj-clhep/
#include  "CLHEP/Vector/ThreeVector.h"
#include  "CLHEP/Matrix/Matrix.h"

// Header files defined by the author in ./source folder
#include "NDA_data_struct.h"
#include "NDA_atom.h"
#include "NDA_molecule.h"
#include "NDA_mole_h2o.h"
#include "NDA_symbox.h"
#include "NDA_symbox_h2o.h"
#include "NDA_symbox_h2o_boxshape.h"
#include "NDA_symbox_h2o_jmol.h"
#include "NDA_symbox_ethanol_jmol.h"
#include "NDA_symbox_ethanol_80.h"
#include "NDA_symbox_dmso_90.h"
#include "NDA_symbox_dmso_90_mdbox.h"
#include "NDA_symbox_dmso_90_mdmol.h"
#include "NDA_symbox_dmso_50_mdmol.h"

#include "NDA_symbox_dmso_60_mdmol.h"
#include "NDA_symbox_dmso_70_mdmol.h"
#include "NDA_symbox_dmso_80_mdmol.h"


#include "NDA_symbox_sio2.h"
#include "NDA_func_main.h"
#include "NDA_func_array.h"
#include "NDA_func_array_gpu.h"
#include "NDA_func_matrix.h"
#include "NDA_func_file.h"
#include "NDA_func_pdf.h"
#include "NDA_func_pdf_omp.h"
#include "NDA_func_pdf_gpu.h"
#include "NDA_func_nsf.h"
#include "NDA_func_simu.h"
#include "NDA_func_pot.h"
#include "NDA_func_temp.h"
#include "atomtables.h"


//=================================================
// New header files

// Global variable
#include "NDA_glob_var_run_def.h"
#include "NDA_glob_var_box_def.h"
#include "NDA_glob_var_simu_def.h"
#include "NDA_glob_var_pdfnsf_def.h"
#include "NDA_glob_var_pdfpot_def.h"
#include "NDA_glob_var_epsr_cpu_def.h"

#include "NDA_func_init_simubox.h"
#include "NDA_func_atomtype.h"
#include "NDA_func_refpot.h"
#include "NDA_func_printpot.h"
#include "NDA_func_nuctype.h"
#include "NDA_func_read_nsf_data.h"
#include "NDA_func_weight_matrix.h"

#include "NDA_func_new_array_pdfpot.h"
#include "NDA_func_new_array_nsfpot.h"
#include "NDA_func_new_matrix.h"
#include "NDA_func_new_array_atomtype.h"
#include "NDA_func_new_array_nuctype.h"
#include "NDA_func_new_array_rmcepsr.h"

#include "NDA_func_nsf_init.h"
#include "NDA_func_exppot.h"
#include "NDA_func_exppot.h"
#include "NDA_func_init_var_rmcepsr.h"

#ifdef USE_MPI
#include  "NDA_func_mpi_bcast.h"
#endif

#ifdef USE_GPU
#include "NDA_glob_var_epsr_gpu_def.h"
#include "NDA_func_new_array_gpu.h"
#include "NDA_func_delete_array_gpu.h"
#include "NDA_func_rmcepsr_gpu.h"
#endif

#include "NDA_func_rmcepsr.h"
#include "NDA_func_parallel_main.h"



#endif 
