//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_H
#define NDA_SYMBOX_H  1

#include <iostream>
#include <iomanip>
#include <math.h>
#include <cmath>
#include <string>
#include <sstream>
#include <stdlib.h>
#include <time.h>
#include <map>


#include  "NDA_molecule.h"
#include  "NDA_mole_h2o.h"
#include  "NDA_func_file.h"
#include  "atomtables.h"
#include  "NDA_data_struct.h"


using namespace std;

#define Avogadro 6.02214179e+23

#include <vector>
//typedef std::vector<NDA_molecule> Vmolecule;
//typedef std::vector<NDA_mole_h2o> Vmole_h2o;
typedef std::vector<NDA_molecule *> Vmole_pointer;

class NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_h2o;

    public:
    NDA_symbox(){};
    ~NDA_symbox(){};

    void SetNameBox(std::string name_input) { name_box = name_input; } 
    std::string GetNameBox() { return name_box; }

    /*    
	  virtual     void Initialize(
	  int     & num_mol_input, 
	  double     mol_wt_input,
	  double    density_input, 
	  bool          set_coord,
	  bool     grid_or_random,
	  bool          use_shell,
	  double          r_shell 
	  ) = 0;

	  virtual     void Initialize_Sample(int  num_mol_input,  string name_sample,  bool  set_nuc_name) = 0;
	  */


    virtual     void Initialize(int  & num_mol_input, bool  set_coord) = 0;
//    virtual     void Initialize_Cube(int  & num_mol_input, bool  set_coord);


    inline  double GetBoxSize() { return  boxsize; }

    inline  vector< int > & GetIndexMolInBoxVec() { return index_mol_inbox_vec; }

    inline  int GetNumAtomInBox() { return num_atom_inbox;}
    inline  int GetNumNucInBox()  { return num_nuc_inbox; }
    inline  int GetNumMolInBox()  { return num_mol_inbox; }

    inline  int GetNumAtomTypeInEpsrInBox()  { return num_atomtype_inepsr_inbox; }

    inline  vector< string > & GetNameNucInBoxVec() { return name_nuc_inbox_vec; }
    inline  vector< string > & GetNameAtomTypeInBoxVec() { return name_atomtype_inbox_vec; }

    inline  vector< int >  &   GetNumAtomInNucInBoxVec() { return num_atom_innuc_inbox_vec; }
    inline  vector< int >  &   GetNumAtomInEpsrInBoxVec() { return num_atom_inepsr_inbox_vec; }

    inline  vector< vector< vector< int > > > GetIndexNucAtomSampleInNucInBoxVec3D()
    { return index_nuc_atom_sample_innuc_inbox_vec_3d; }

    inline  vector< vector<CLHEP::Hep3Vector > > & GetCoordAtomInNucInBoxVec() 
    { return coord_atom_innuc_inbox_vec; }

    inline  vector< vector<CLHEP::Hep3Vector > > & GetCoordAtomInEpsrInBoxVec() 
    { return coord_atom_inepsr_inbox_vec; }

    inline  vector< vector<std::string > >  &  GetNameNucAtomInEpsrInBoxVec() 
    { return name_nuc_atom_inepsr_inbox_vec; }

    inline  vector< vector<      int  > >  &  GetIndexMolAtomInEpsrInBoxVec() 
    { return index_mol_atom_inepsr_inbox_vec; }

    void SetCoordAtomInBoxVec( vector<CLHEP::Hep3Vector >  coord_atom_inbox_inbox_vec_input );
    inline   vector<CLHEP::Hep3Vector >  & GetCoordAtomInBoxVec() 
    { return coord_atom_inbox_inbox_vec; }

    void  GenerateCoordAtomInBoxVec();

    void SetNameNucMolAtomInBoxVec( 
	    vector<std::string >        name_nuc_atom_inbox_inbox_vec_input
	    );

    inline   vector<std::string >  & GetNameNucAtomInBoxVec() 
    { return name_nuc_atom_inbox_inbox_vec; }

    void SetCoordAtomInMolVec( vector<CLHEP::Hep3Vector >  coord_atom_inmol_inbox_vec_input );
    inline   vector<CLHEP::Hep3Vector >  & GetCoordAtomInMolVec() 
    { return coord_atom_inmol_inbox_vec; }

    void SetCoordMolComInBoxVec( vector<CLHEP::Hep3Vector >  coord_mol_com_inmol_inbox_inbox_vec_input );
    inline   vector<CLHEP::Hep3Vector >  & GetCoordMolComInBoxVec() 
    { return coord_mol_com_inbox_inbox_vec; }

    inline  vector< double >  & GetEnergyMolInBoxVec() { return energy_mol_inbox_vec; }

    void SetCoordMolAtomInBoxVec( 
	    vector< CLHEP::Hep3Vector >  coord_atom_inbox_inbox_vec_input,
	    vector< CLHEP::Hep3Vector >  coord_atom_inmol_inbox_vec_input,
	    vector< CLHEP::Hep3Vector >  coord_mol_com_inbox_inbox_vec_input,
	    vector< std::string       >  name_nuc_atom_inbox_inbox_vec_input
	    );


    void SetNameAtomTypeInBoxVec( vector< string > name_atomtype_inbox_vec_input );


    void   ClassifyAtomToNuc (int index_procs);
    void   ClassifyAtomToNucTypeSample(int index_procs);
    void   ClassifyAtomToEpsr(int index_procs);
    void   ClassifyAtomToEpsrSample(int index_procs);
    void   ClassifyAtomToAtomTypeBasic(int index_procs); 
    void   ClassifyAtomToEpsr_NewSample(int index_procs); 
    void   ClassifyAtomToEpsrToNuc_Sample(int index_procs); 
    void   ClassifyAtomToAtomTypeBasic_MapSample(vector<NDA_symbox>  sim_box_sample_vec, int index_procs);

    void   UpdateCoordAtomInBoxFromNucType(int index_procs);
    void   UpdateCoordAtomInBoxFromEpsrAtomType(int index_procs);


    void Print();
    void PrintBoxToGro(std::string name_dir, std::string name_file);

    void CalculatePDF(double binsize_input);
    void PrintPDF(std::string name_dir);
    void CalculateNSF(double binsize_input, double q_max);
    void CalculateNSF2(double binsize_input, double q_max);
    void PrintNSF(std::string name_dir);

    vector< int > index_mol_inbox_vec;

    int num_atom_inbox;
    int index_atom_inbox;
    int num_nuc_inbox;
    int num_atomtype_inepsr_inbox;


    vector< string > name_nuc_inbox_vec;
    vector< string > name_atomtype_inbox_vec;
    vector< int >    num_atom_innuc_inbox_vec;
    vector< int >    num_atomtype_inmol_inepsr_inbox_vec;
    vector< int >    num_atom_inepsr_inbox_vec;

    vector< vector<CLHEP::Hep3Vector > > coord_atom_innuc_inbox_vec;
    vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d;
    vector< vector<CLHEP::Hep3Vector > >         coord_atom_inepsr_inbox_vec;
    vector< vector<std::string > >            name_nuc_atom_inepsr_inbox_vec;
    vector< vector<  int  > >                index_mol_atom_inepsr_inbox_vec;

    vector<CLHEP::Hep3Vector >  coord_atom_inbox_inbox_vec;
    vector<CLHEP::Hep3Vector >  coord_atom_inmol_inbox_vec;
    vector<CLHEP::Hep3Vector >  coord_mol_com_inbox_inbox_vec;
    vector< double >            energy_mol_inbox_vec;

    vector< std::string >       name_nuc_atom_inbox_inbox_vec;

    vector < std::string >   name_moltype_inepsr_inbox_vec;

    void   GenerateCoordBAtomInBoxVec(std::map<string, double> b_nuc_map);
    void   GenerateCoordBAtomInBoxVecSample(std::map<string, double> b_nuc_map);
    void   GenerateBAtomInBoxVec(std::map<string, double> b_nuc_map);
    void     UpdateCoordBAtomInBoxVec( );
    void     UpdateCoordAtomInBoxVec( );

    inline  vector< coord_b_atom_struct > & GetCoordBAtomInBoxVec(){ return  coord_b_atom_inbox_vec; }
    inline  vector< double > & GetBAtomInBoxVec(){ return b_atom_inbox_vec; }

    vector< coord_b_atom_struct >    coord_b_atom_inbox_vec; 
    vector< double >    b_atom_inbox_vec; 

    // private:
    protected:
    std::string name_box;
    int num_mol_inbox;
    double boxsize;
    double binsize_r;

    vector< vector< int > > num_atompair_box;
    vector< vector< double > > num_atompair_box_mean;
    vector< vector< double > > pdf_atompair_box;
    vector< double > r_list;

    vector< double > nsf_box;
    vector< double > q_list;


    //Need to be edited by users: change Vmole_h2o to your own molecule vector
    public:

    // Vmolecule mol_inbox_vec;
    //   Vmole_h2o mol_inbox_vec;
    Vmole_pointer    mol_inbox_vec;

    // inline  Vmolecule & GetMolInBoxVec() { return mol_inbox_vec; };
    // inline  Vmole_h2o & GetMolInBoxVec() { return mol_inbox_vec; }; 
    inline  Vmole_pointer & GetMolInBoxVec() { return mol_inbox_vec; }; 

};

    double Conv_density_mass2atom(double density_mass, double mass_atom_av);


#endif 
