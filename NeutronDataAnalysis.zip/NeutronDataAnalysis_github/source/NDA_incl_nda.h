#ifndef NDA_INCL_NDA_H
#define NDA_INCL_NDA_H  1

// Header files defined by the author in ./source folder
#include "NDA_data_struct.h"
#include "NDA_atom.h"
#include "NDA_molecule.h"
#include "NDA_mole_h2o.h"
#include "NDA_symbox.h"


#endif 
