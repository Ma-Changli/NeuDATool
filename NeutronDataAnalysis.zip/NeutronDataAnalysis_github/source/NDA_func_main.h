#ifndef NDA_FUNC_MAIN_H
#define NDA_FUNC_MAIN_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_symbox_h2o.h"
#include "NDA_symbox_h2o_boxshape.h"
#include "NDA_symbox_h2o_jmol.h"
#include "NDA_symbox_ethanol_jmol.h"
#include "NDA_symbox_ethanol_80.h"
#include "NDA_symbox_dmso_90.h"
#include "NDA_symbox_dmso_90_mdbox.h"
#include "NDA_symbox_dmso_90_mdmol.h"
#include "NDA_symbox_dmso_50_mdmol.h"
#include "NDA_symbox_pdea_80.h"


#include "NDA_symbox_dmso_60_mdmol.h"
#include "NDA_symbox_dmso_70_mdmol.h"
#include "NDA_symbox_dmso_80_mdmol.h"

#include "NDA_func_new_array_nsfpot.h"


namespace NDA_FUNC_MAIN {

    void Set_Para_Run();

    void Set_Para_Run_DFLT();
    void Set_Para_Run_INPT();
    void Set_Para_ExpData_H2O();
    void Set_Para_ExpData_H2O_BoxShape();
    void Set_Para_ExpData_SiO2();
//    void Set_Para_SimuBox();

    void Set_Para_ExpData_H2O_JMOL();
    void Set_Para_ExpData_ETHANOL_80();
    void Set_Para_ExpData_DMSO_90();
    void Set_Para_ExpData_DMSO_50();
    void Set_Para_ExpData_DMSO_60();
    void Set_Para_ExpData_DMSO_70();
    void Set_Para_ExpData_DMSO_80();
    void Set_Para_ExpData_PDEA_80();

    void Create_Directory_Results();
    void Print_Debug_Info_Init();

    void Set_Para_Simu();

    //    void Init_Nuc_B();
    void Init_AtomType();

} // End namespace NDA_FUNC
#endif 
