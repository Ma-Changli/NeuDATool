//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_PDEA_80_H
#define NDA_SYMBOX_PDEA_80_H  1

#include  "NDA_symbox.h"
#include  "NDA_mole_h2o_jmol.h"
#include  "NDA_mole_ethanol_jmol.h"
#include  "NDA_mole_pdea_gro.h"

class NDA_symbox_pdea_80 : public NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_h2o_jmol;
    friend class NDA_mole_ethanol_jmol;
    friend class NDA_mole_pdea_gro;

    public:
    NDA_symbox_pdea_80(){};
    ~NDA_symbox_pdea_80(){};

    void Initialize(
	    int  & num_mol_input, 
	    bool   set_coord
	    );


    //Users only need to copy the function to the new class and change the NDA_symbox_h2o to your own box class name
    //    void   ClassifyAtomToAtomTypeBasic_MapSample(vector<NDA_symbox_h2o>  sim_box_sample_vec, int index_procs);

};

#endif 
