bool     have_q_pot_cut;

double        q_pot_min;
double        q_pot_max;
int     num_bin_qqq_fit;

double chisq_fit_nsf_max;

// Move molecule randomly  
//==========================================================================
int        index_mov_mol;
int        index_mov_atom;

bool       is_mov_mol ;
bool       is_mov_atom;

double     energy_mol_pre;
double     energy_mol_new;
double     exponent_factor;

bool       is_trans_or_rot;   //If it is  translation, the value is true

// in moved atom order
vector< int >                        index_atomtype_movedatom_inbox_vec;
vector< int >                 index_atom_inatomtype_movedatom_inbox_vec;
vector< CLHEP::Hep3Vector >             delta_coord_movedatom_inbox_vec;

// in moved atomtype order
vector< int >                                                 index_atomtype_movedatomtype_inbox_vec;
vector< vector< int > >                 index_atom_inatomtype_movedatom_inmovedatomtype_inbox_vec_2d;
vector< vector< CLHEP::Hep3Vector > >             delta_coord_movedatom_inmovedatomtype_inbox_vec_2d;

double  x_trans;
double  y_trans;
double  z_trans;
CLHEP::Hep3Vector  xyz_trans; 
CLHEP::Hep3Vector  delta_coord_atom_moved; 

double x_axis;
double y_axis;
double z_axis;
CLHEP::Hep3Vector  axis_rot; 
double angle_rot;

double    *delta_coord_arom_moved_arr;

double          pot_inbox_pre;
double          pot_inbox_new;
double    delta_pot_inbox;

vector< double >  pot_inbox_vec;

bool is_move_accepted;

long     i_move_molatom    ;
long     i_move_molatom_try;

long     i_move_molatom_samepot    ;
long     i_move_molatom_samepot_try;
long     i_move_molatom_samepot_try_real;
long     num_move_molatom_samepot_max;
int                factor_move_mole;

double   accept_ratio_move_new;
double   accept_ratio_move_pre;
double   accept_ratio_move_diff;

double   ratio_emp_vs_ref;

bool     have_delta_nr;

bool     begin_move_atom;

int      num_atom_moved;

bool     should_update_pot;
bool     have_update_pot; 
int      index_update_pot; 

double  * chisq_nsf_epsr_pre_arr    ;
double  * chisq_nsf_epsr_new_arr    ;
double  * chisq_nsf_rmc_pre_arr ;
double  * chisq_nsf_rmc_new_arr ;

double  chisq_nsf_rmc_pre;
double  chisq_nsf_rmc_new;

double    chisq_nsf_uplimit;


bool    is_epsr_equilibrium;


string          name_file_chisq_nsf_str;
ofstream      output_file_chisq_nsf;

// Whether  accumulate data after EPMC reachs equilibrium
bool    is_accumulate_data;
//  is_accumulate_data  = true;

int   i_sum_nsf    ;
int num_sum_nsf_max;


string          name_file_sum_nsf_str;
ofstream      output_file_sum_nsf;

bool is_continue_simu;

int *  have_delta_nr_arr; 


