//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).


#ifndef NDA_ATOM_H
#define NDA_ATOM_H  1

#include <iostream>
#include <fstream>
#include <string>
#include  "CLHEP/Vector/ThreeVector.h"

using namespace std;
using namespace CLHEP;

class NDA_atom {

    public:
	NDA_atom();
	~NDA_atom(){};

	//========================================================
	inline void   SetNameAtom(std::string name_input){ name_atom = name_input; }
	inline string GetNameAtom(){ return name_atom; }

	inline void   SetNameAtomInEpsr(std::string name_input){ name_atom_inepsr = name_input; }
	inline string GetNameAtomInEpsr(){ return name_atom_inepsr; }

	inline void   SetNameNuc(std::string name_input){  name_nuc = name_input; }
	inline string GetNameNuc(){ return name_nuc; }

	inline void   SetNameMol(std::string name_input){  name_mol = name_input; }
	inline string GetNameMol(){ return name_mol; }

	inline void   SetNameRes(std::string name_input){  name_res = name_input; }
	inline string GetNameRes(){ return name_res; }

	inline void   SetNameAtomInGro(std::string name_input){  name_atom_ingro = name_input; }
	inline string GetNameAtomInGro(){ return name_atom_ingro; }


	//========================================================
	inline void SetIndexAtomInBox(int index){  index_atom_inbox = index; }
	inline int  GetIndexAtomInBox(){return index_atom_inbox; } 

	inline void SetIndexAtomInNucInBox(int index){  index_atom_innuc_inbox = index; }
	inline int  GetIndexAtomInNucInBox(){return index_atom_innuc_inbox; } 

	inline void SetIndexAtomInAtomTypeInEpsrInBox(int index){  index_atom_inatomtype_inepsr_inbox = index; }
	inline int  GetIndexAtomInAtomTypeInEpsrInBox(){return index_atom_inatomtype_inepsr_inbox; } 

	inline void SetIndexAtomTypeInEpsrInBox(int index) {  index_atomtype_inepsr_inbox = index; }
	inline int  GetIndexAtomTypeInEpsrInBox() {return index_atomtype_inepsr_inbox; } 

	inline void SetIndexAtomInMol(int index){  index_atom_inmol = index; }
	inline int  GetIndexAtomInMol(){return index_atom_inmol; } 

	inline void SetIndexNucInBox(int index){  index_nuc_inbox = index; }
	inline int  GetIndexNucInBox(){return index_nuc_inbox; } 

	inline void SetIndexMol(int index){  index_mol = index; }
	inline int  GetIndexMol(){return index_mol;} 

	inline void SetIndexRes(int index){  index_res = index; }
	inline int  GetIndexRes() {return index_res;} 

	inline void  SetCoordInBox(CLHEP::Hep3Vector coord_input){ coord_atom_inbox = coord_input;}
	inline Hep3Vector GetCoordInBox() { return coord_atom_inbox;}

	inline void       SetCoordInMol(CLHEP::Hep3Vector coord_input){ coord_atom_inmol = coord_input;}
	inline Hep3Vector GetCoordInMol() {return coord_atom_inmol;} ;

	inline Hep3Vector GetDeltaCoord() {return delta_coord_atom;} ;
	inline void       SetDeltaCoord(CLHEP::Hep3Vector delta_coord_input) 
	{delta_coord_atom = delta_coord_input;} ;


	inline Hep3Vector GetDeltaCoordTemp() {return delta_coord_atom_temp;} ;
	inline void       SetDeltaCoordTemp(CLHEP::Hep3Vector delta_coord_input) 
	{delta_coord_atom_temp = delta_coord_input;} ;


	inline double     GetMassDalton() {return mass_dalton;} ;
	inline void       SetMassDalton(double mass_dalton_input) 
	{mass_dalton = mass_dalton_input;} ;




	void Translation(CLHEP::Hep3Vector xyz_delta, double boxsize);
	void Rotate(CLHEP::Hep3Vector & axis, double delta, double boxsize);

	void TranslationAttempt(CLHEP::Hep3Vector xyz_delta, double boxsize);
	void RotateAttempt(CLHEP::Hep3Vector & axis, double delta, double boxsize);

	inline	void ConfirmAtomMove(bool is_rotate)
	{
	    coord_atom_inbox  = coord_atom_inbox_temp;
	    delta_coord_atom  = delta_coord_atom_temp;

	    if(is_rotate)
	    {
		coord_atom_inmol = coord_atom_inmol_temp;
	    }
	}



	inline void ConfirmAtomMoveFromDeltaCoord(CLHEP::Hep3Vector xyz_delta, bool is_rotate, double boxsize)
	{
	    //  coord_atom_inbox  = coord_atom_inbox_temp; 
	    coord_atom_inbox  += xyz_delta; //  For MPI

	    if(coord_atom_inbox[0] > boxsize) coord_atom_inbox[0] -= boxsize;
	    if(coord_atom_inbox[1] > boxsize) coord_atom_inbox[1] -= boxsize;
	    if(coord_atom_inbox[2] > boxsize) coord_atom_inbox[2] -= boxsize;

	    if(coord_atom_inbox[0] < 0.0) coord_atom_inbox[0] += boxsize;
	    if(coord_atom_inbox[1] < 0.0) coord_atom_inbox[1] += boxsize;
	    if(coord_atom_inbox[2] < 0.0) coord_atom_inbox[2] += boxsize;

	    delta_coord_atom  = xyz_delta;

	    if(is_rotate)
	    {
		coord_atom_inmol += xyz_delta;
	    }
	}



	void Print();

    private:
	std::string name_atom;
	//	std::string name_atom_innda;  // The name of atom used in display NDA results.
	std::string name_atom_inepsr;  // The name of atom used in display NDA results.
	std::string name_nuc;         // The name of atom used in NDA calculation.
	std::string name_mol;
	std::string name_res;
	std::string name_atom_ingro;

	int  index_atom_inbox;
	int  index_atom_inmol;
	int  index_nuc_inbox;
	int  index_atom_innuc_inbox;

	int  index_atomtype_inepsr_inbox;
	int  index_atom_inatomtype_inepsr_inbox;

	int  index_mol;
	int  index_res;

	CLHEP::Hep3Vector coord_atom_inbox; 
	CLHEP::Hep3Vector coord_atom_inmol; 
	CLHEP::Hep3Vector delta_coord_atom; 

	CLHEP::Hep3Vector coord_atom_inbox_temp; 
	CLHEP::Hep3Vector coord_atom_inmol_temp; 
	CLHEP::Hep3Vector delta_coord_atom_temp; 

	double mass_dalton;  //mass_amu; atomic mass unit 
	// The unified atomic mass unit or dalton (symbol: u, or Da or AMU) is a standard unit of mass that quantifies mass on an atomic or molecular scale (atomic mass). 

};

#endif 
