//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_PARAMETER_POT_H
#define NDA_PARAMETER_POT_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"

using namespace std;
using namespace CLHEP;


//double O_H2O[num_para_pot] = {epsilon, sigma, 0.0, 0.0, 0.0} //KJ/mol, angstrom

const unsigned num_para_pot_lj = 5;
std::map <string, double*>  para_pot_lj;

//double O_H2O_lj[num_para_pot_lj] = {6.502, 4.166};
double O_H2O_lj[num_para_pot_lj] = {0.65, 3.166}; //Soper
//para_pot_lj["O_H2O"] = O_H2O_lj;  // This can not be used in C++11 
para_pot_lj.insert(make_pair("O_H2O", O_H2O_lj));

//double H_H2O_lj[num_para_pot_lj] = {3.0, 2.0};
double H_H2O_lj[num_para_pot_lj] = {0.0, 0.0}; //Soper
para_pot_lj.insert(make_pair("H_H2O", H_H2O_lj));

const unsigned num_para_pot_ep = 5;
std::map <string, double*>  para_pot_ep;

//double O_H2O_ep[num_para_pot_ep] = {-1.0}; 
double O_H2O_ep[num_para_pot_ep] = {-0.8476}; //Soper
//para_pot_ep["O_H2O"] = O_H2O_ep;
para_pot_ep.insert(make_pair("O_H2O", O_H2O_ep));

double H_H2O_ep[num_para_pot_ep] = {0.4238}; //Soper
//para_pot_ep["H_H2O"] = H_H2O_ep;
para_pot_ep.insert(make_pair("H_H2O", H_H2O_ep));



#endif 
