// Empirical Potential  Poisson , poisson
//==========================================================================
double   val_sigma_qqq_emp ;
double   val_sigma_rad_emp ;
double   rad_poisson_min ;
double   rad_poisson_max ;

int      num_poisson_emp;

double  interval_rad_base; // Why -2.0 * rad_poisson_min?
double *	val_rad_poisson_emp_arr;

double  **  factor_poisson_emp_atompair_sum_arr_2d        ;
double  **  factor_poisson_emp_atompair_fit_arr_2d ;

double  **  factor_poisson_emp_sample_arr_2d ;

double  **  pot_poisson_emp_rad_arr_2d ;
double  **  pot_poisson_emp_qqq_arr_2d ;





