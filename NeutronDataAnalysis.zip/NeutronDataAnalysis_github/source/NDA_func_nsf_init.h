#ifndef NDA_FUNC_NSF_INIT_H
#define NDA_FUNC_NSF_INIT_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_glob_var_pdfnsf_dec.h"

#include "NDA_func_array.h"
#include "NDA_func_file.h"
#include "NDA_func_pdf.h"
#include "NDA_func_pdf_gpu.h"
#include "NDA_func_nsf.h"

namespace NDA_FUNC_NSF_INIT{

//    void New_NSF_ARR();
    void Calc_NSF_Init();
    void Print_NSF_Init();
}
#endif
