//extern double boxsize_div_2;

extern  int    ** delta_num_atompair_inepsr_gpu_arr_2d_h; 
extern  int    ** delta_num_atompair_inepsr_gpu_arr_2d ;

extern  int    num_atom;
extern  int    memsize;
extern  int    memsize_cpu;
extern  int    memsize_gpu;

extern  int *	num_block_arr;

extern  int ** index_mol_atom_cpu_arr_2d  ; 
extern  int ** index_mol_atom_gpu_arr_2d_h; 
extern  int ** index_mol_atom_gpu_arr_2d; 


extern  double ** coord_xyz_cpu_arr_2d  ;
extern  double ** coord_xyz_gpu_arr_2d_h; 
extern  double ** coord_xyz_gpu_arr_2d; 


extern  double * coord_xyz_00_cpu;  // The first is old, and the second is new
extern  double * coord_xyz_01_cpu;  // The first is old, and the second is new

extern  double * coord_xyz_00_gpu; 
extern  double * coord_xyz_01_gpu; 

extern  double    ** val_nsf_diff_fit_gpu_arr_2d_h ; 
extern  double    ** val_nsf_diff_fit_gpu_arr_2d;
extern  double    ** val_nsf_diff_gpu_arr_2d_h    ; 
extern  double    ** val_nsf_diff_gpu_arr_2d;

extern  double  **  pot_poisson_emp_rad_gpu_arr_2d_h;
extern  double  **  pot_poisson_emp_qqq_gpu_arr_2d_h;
extern  double  **  pot_poisson_emp_rad_gpu_arr_2d;
extern  double  **  pot_poisson_emp_qqq_gpu_arr_2d;

extern  double *  chisq_fit_q_pot_cpu_arr;
extern  double *  chisq_fit_q_pot_gpu_arr;



