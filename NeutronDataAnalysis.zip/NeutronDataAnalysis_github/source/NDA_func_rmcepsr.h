#ifndef NDA_FUNC_RMCEPSR_H
#define NDA_FUNC_RMCEPSR_H  1

using namespace std;

#include <cstdio>
#include <ctime>


#ifdef USE_MPI
#include <mpi.h>
#endif

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

#include "NDA_glob_var_pdfnsf_dec.h"
#include "NDA_glob_var_pdfpot_dec.h"
#include "NDA_glob_var_epsr_cpu_dec.h"
#include "NDA_glob_var_epsr_gpu_dec.h"


#include "NDA_func_array.h"
#include "NDA_func_file.h"
#include "NDA_func_pdf.h"
#include "NDA_func_nsf.h"
#include "NDA_func_simu.h"
#include "NDA_func_temp.h"


#ifdef USE_GPU
#include  "NDA_func_gpu_basic.h"
#include  "NDA_func_gpu_main_dec.h"
#include  "NDA_func_array_gpu.h"
#include  "NDA_func_pdf_gpu.h"
#endif


namespace NDA_FUNC_RMCEPSR {

    void Set_Random_Move_Var();    

    void  Sort_Moved_Atom();

    void Calc_Delta_NR_CPU();
    void Calc_Delta_NR_GPU();
    void Decide_Accept_Move();
    void Confirm_Move_CPU();
    void Confirm_Move_GPU();
    void Decide_Update_Pot();
    void Print_Debug_Info();
    void Print_BoxToGro();
    void Calc_PDF_CPU();
    void Calc_PDF_GPU();
    void Calc_NSF();
    void Print_NSF();
    void Print_PDF_NSF_Sum();

    void Calc_Chisq_NSF_SimuData();
    void Calc_Delta_NSF();


    void Fit_ExpPot();
    void Print_Delta_NSF(); 
    void Add_ExpPot_To_RefPot();
    void Print_ExpPot();

} 
#endif 
