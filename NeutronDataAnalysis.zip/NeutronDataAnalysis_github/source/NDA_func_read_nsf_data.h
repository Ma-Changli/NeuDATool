#ifndef NDA_FUNC_READ_NSF_DATA_H
#define NDA_FUNC_READ_NSF_DATA_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_func_array.h"
#include "NDA_func_file.h"

namespace NDA_FUNC_READ_NSF_DATA {

    void Read_NSF_Data();

    void Add_BKGD_NSF_Data();

} // End namespace NDA_FUNC
#endif 
