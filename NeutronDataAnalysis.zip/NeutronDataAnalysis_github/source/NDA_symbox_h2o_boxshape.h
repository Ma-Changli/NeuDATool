//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_H2O_BOXSHAPE_H
#define NDA_SYMBOX_H2O_BOXSHAPE_H  1

#include  "NDA_symbox.h"
#include  "NDA_mole_h2o.h"

class NDA_symbox_h2o_boxshape : public NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_h2o;

    public:
    NDA_symbox_h2o_boxshape(){};
    ~NDA_symbox_h2o_boxshape(){};

    void Initialize(
	    int     & num_mol_input, 
	    bool          set_coord
	    );

 
};

#endif 
