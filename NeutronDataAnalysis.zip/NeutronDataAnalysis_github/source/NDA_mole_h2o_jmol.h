//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_MOLE_H2O_JMOL_H
#define NDA_MOLE_H2O_JMOL_H  1

#include "NDA_molecule.h"

class NDA_mole_h2o_jmol : public NDA_molecule {

    friend class NDA_atom;

    public:
    NDA_mole_h2o_jmol(){};
    ~NDA_mole_h2o_jmol(){};

    //    void  Initialize_H2O(bool is_set_coord);
    //    void  Initialize_H2O_Sample(string name_sample, bool set_nuc_name);

    void  Initialize(bool is_set_coord);
    void  Initialize_Sample(string name_sample, bool set_nuc_name);

    //    void   CalculateEnergyMol();
    //    void   CalculateEnergyMol_H2O();
    //    void   CalculateEnergyMol_H2O_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);

    //    void   CalculateEnergyMol_Harm();
    //    void   CalculateEnergyMol_Harm_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);
    //    void   CalculateEnergyMol_Harm_Temp(CLHEP::Hep3Vector delta_coord_atom);

    void   CalculateEnergyMol();
    void   CalculateEnergyMol_Temp(int index_atom, CLHEP::Hep3Vector delta_coord_atom);
    void   CalculateEnergyMol_Temp(CLHEP::Hep3Vector delta_coord_atom);

};

#endif 

