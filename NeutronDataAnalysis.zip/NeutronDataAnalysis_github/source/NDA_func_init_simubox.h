#ifndef NDA_FUNC_INIT_SIMUBOX_H
#define NDA_FUNC_INIT_SIMUBOX_H  1

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

using namespace std;
using namespace CLHEP;

namespace NDA_FUNC_INIT_SIMUBOX {

    void Init_SimuBox_H2O();
    void Init_SimuBox_H2O_BoxShape();
    void Init_SimuBox_SiO2();

    void Init_SimuBox_H2O_JMOL();
    void Init_SimuBox_ETHANOL_80();
    void Init_SimuBox_DMSO_90();
    void Init_SimuBox_DMSO_50();
    void Init_SimuBox_DMSO_60();
    void Init_SimuBox_DMSO_70();
    void Init_SimuBox_DMSO_80();
    void Init_SimuBox_PDEA_80();

    void Init_MPI_ARR();
    void Read_MPI_ARR();
    void Print_Box_To_Gro();
    void Set_Info_Box();
    void Print_Info_Box();

} // End namespace NDA_FUNC

#endif 
