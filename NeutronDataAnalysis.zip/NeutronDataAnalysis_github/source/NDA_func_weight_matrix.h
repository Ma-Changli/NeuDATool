#ifndef NDA_FUNC_WEIGHT_MATRIX_H
#define NDA_FUNC_WEIGHT_MATRIX_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

#include "NDA_func_matrix.h"

namespace NDA_FUNC_WEIGHT_MATRIX{

    void Set_Weight_Matrix_BKGD_H2O();
    void Set_Weight_Matrix_BKGD_SiO2();
    void Set_Weight_Matrix_BKGD_H2O_JMOL();
    void Set_Weight_Matrix_BKGD_ETHANOL_80();
    void Set_Weight_Matrix_BKGD_PDEA_80();

    void Set_Weight_Matrix_BKGD_DMSO_90();
    void Set_Weight_Matrix_BKGD_DMSO_50();
    void Set_Weight_Matrix_BKGD_DMSO_60();
    void Set_Weight_Matrix_BKGD_DMSO_70();
    void Set_Weight_Matrix_BKGD_DMSO_80();

} 
#endif 
