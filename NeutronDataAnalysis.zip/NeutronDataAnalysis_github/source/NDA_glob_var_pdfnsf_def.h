int     **       num_atompair_inatomtype_arr_2d      ;
double  **       num_atompair_inatomtype_mean_arr_2d ;
double  **       pdf_atompair_inatomtype_arr_2d      ;
//double  **       pdf_atompair_inatomtype_sum_arr_2d      ;

double    *  val_qqq_simu_arr ;
double    *  val_qqq_simu_set_arr ;
double **       val_hq_atompair_simu_arr_2d;  
double **       val_hq_atompair_simu_set_arr_2d;  

double **       val_nsf_sample_simu_sum_arr_2d     ;
double *        val_nsf_sample_simu_sum_arr_2d_mpi ;  

double **       val_nsf_sample_simu_sum_set_arr_2d     ;
double *        val_nsf_sample_simu_sum_set_arr_2d_mpi ;  


double   ** val_nsf_diff_sample_arr_2d    ;  
double   ** val_nsf_diff_sample_fit_arr_2d ;  
double   ** chi_nsf_diff_sample_fit_arr_2d ;  

double   ** val_nsf_diff_atompair_arr_2d ;  
double   ** val_nsf_diff_atompair_fit_arr_2d ;  

double **       delta_nsf_datapdf_forpot_arr_2d ;












