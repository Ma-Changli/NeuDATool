#ifndef NDA_FUNC_INIT_VAR_RMCEPSR_H
#define NDA_FUNC_INIT_VAR_RMCEPSR_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_glob_var_pdfnsf_dec.h"
#include "NDA_glob_var_pdfpot_dec.h"

#include "NDA_glob_var_epsr_cpu_dec.h"

#include "NDA_func_temp.h"

namespace NDA_FUNC_INIT_VAR_RMCEPSR
{ 

void Init_Var_RMCEPSR();

}

#endif
