#ifndef NDA_FUNC_DELETE_ARRAY_GPU_H
#define NDA_FUNC_DELETE_ARRAY_GPU_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_glob_var_pdfnsf_dec.h"
#include "NDA_glob_var_pdfpot_dec.h"

#include "NDA_glob_var_epsr_cpu_dec.h"
#include "NDA_glob_var_epsr_gpu_dec.h"

#include "NDA_func_gpu_basic.h"

namespace NDA_FUNC_DELETE_ARRAY_GPU
{ 

    void Delete_Array_GPU();

}

#endif
