#ifndef NDA_GLOB_VAR_BOX_DEC_H
#define NDA_GLOB_VAR_BOX_DEC_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"
#include "NDA_symbox_h2o.h"
#include "NDA_symbox_h2o_boxshape.h"
#include "NDA_symbox_h2o_jmol.h"
#include "NDA_symbox_ethanol_jmol.h"
#include "NDA_symbox_ethanol_80.h"
#include "NDA_symbox_dmso_90.h"
#include "NDA_symbox_dmso_90_mdbox.h"
#include "NDA_symbox_dmso_90_mdmol.h"
#include "NDA_symbox_dmso_50_mdmol.h"

#include "NDA_symbox_dmso_60_mdmol.h"
#include "NDA_symbox_dmso_70_mdmol.h"
#include "NDA_symbox_dmso_80_mdmol.h"


#include "NDA_symbox_pdea_80.h"
#include "NDA_symbox_sio2.h"

 
//==================================================
//Variable if simulation box and data
 
// Using Gromacs Simlation data or experiment data 
// Only it is useful when test the program with H2O neutron scattering data
extern  bool    is_read_simu_or_isis;
 
extern  int           num_sample_exp;  // The experiment data file amount
 
extern  vector< string >      name_sample_exp_vec;
extern  vector< string >      name_file_data_exp_vec;
 
extern  vector< vector < int > >    index_sample_inprocs_vec;
extern  vector< int >               index_procs_sample_vec;
 
extern  int num_sample_in_thisprocs;
 
//// Simulation box
//extern  NDA_symbox              sim_box_basic_single;
//extern  NDA_symbox              sim_box_sample_single;
//extern  vector< NDA_symbox >    sim_box_sample_vec; 
 // Simulation box
//extern  NDA_symbox_h2o              sim_box_basic_single;
//extern  NDA_symbox_h2o              sim_box_sample_single;

extern  NDA_symbox   *           sim_box_basic_single;
extern  NDA_symbox   *           sim_box_sample_single;
extern  vector< NDA_symbox_h2o >    sim_box_sample_vec; 
 
extern  int    num_mol_inbox_input;
 
extern  double           boxsize      ;
extern  double           boxsize_div_2;
extern  double        volume_box      ;
extern  double       num_dens_atom_tot;
extern  double  num_atom_inbox_sq     ;
 
extern  CLHEP::Hep3Vector  boxsize_3vector;
 
extern  std::map<string,  double> b_nuc_map;
 
extern  int  num_nuc_inbox_sample_single;
 
extern  vector< int >  num_nuc_sample_vec;
 
extern  vector< int >  num_nucpair_inbox_sample_vec;
 
extern  int      num_nuc_sample_max;
extern  int  num_nucpair_sample_max;
 
extern  int  num_atom_inbox;
 
// Users can initialize simulation box directly by initialize function in NDA_symbox class
extern  int  num_mol_inbox;
 
extern  int num_atom_inmol_inbox_max;  // Set the maximal  atom number of all molecules. In H2O, the number is 3 or larger than 3.  
 
extern  string name_mol;
extern  double wt_mol  ; // g/mol
extern  double density ; // g/cm^3


extern  vector<CLHEP::Hep3Vector >       coord_atom_inbox_inbox_vec;
extern  vector<CLHEP::Hep3Vector >       coord_atom_inmol_inbox_vec;
extern  vector<CLHEP::Hep3Vector >    coord_mol_com_inbox_inbox_vec;
extern  vector<std::string >          name_nuc_atom_inbox_inbox_vec;

extern  double *          coord_mol_com_inbox_inbox_arr;
extern  double *             coord_atom_inbox_inbox_arr;
extern  double *             coord_atom_inmol_inbox_arr;
extern  char   *          name_nuc_atom_inbox_inbox_arr; // 4 character is enough
extern  int    * num_char_name_nuc_atom_inbox_inbox_arr;

extern  string           name_nuc;
extern  int     num_char_name_nuc;

 
extern  int  num_atomtype_inbox;
extern  int  num_atompair_inbox;
 
extern  long     *num_atom_inatomtype_inbox_arr;
extern  double   *density_atomtype_arr         ;
 
extern  double  *         cc_atompair_arr;
extern  double  * factor_nsf_atompair_arr;
 
extern  int index_atompair;
 
extern  string name_atomtype;
extern  vector< string > name_atomtype_inbox_vec;
extern  vector< double > num_atom_atomtype_inbox_vec;
 
extern  vector< vector < int > > index_atompair_inprocs_vec;
extern  vector< int >  index_procs_atompair_vec;
extern  int   num_atompair_in_thisprocs;
extern  vector< string > name_atompair_inbox_vec;
 

//==================
extern  long     ** num_atom_innuctype_sample_arr_2d;
extern  double   **    density_nuctype_sample_arr_2d;
  
extern  double   **       cbb_nuc_sample_arr_2d; 
extern  double   *    cbb_nuc_tot_sample_arr; 

extern  double   *    cbb_bkgd_sample_arr; 
  
extern  int num_nuc_sample_single;

#endif 
