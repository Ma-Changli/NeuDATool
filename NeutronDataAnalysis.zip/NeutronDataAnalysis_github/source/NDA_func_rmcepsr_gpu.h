#ifndef NDA_FUNC_RMCEPSR_GPU_H
#define NDA_FUNC_RMCEPSR_GPU_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

#include "NDA_glob_var_pdfnsf_dec.h"
#include "NDA_glob_var_pdfpot_dec.h"
#include "NDA_glob_var_epsr_cpu_dec.h"
#include "NDA_glob_var_epsr_gpu_dec.h"


#include "NDA_func_array.h"
#include "NDA_func_array_gpu.h"
#include "NDA_func_file.h"
#include "NDA_func_pdf.h"
#include "NDA_func_pdf_gpu.h"
#include "NDA_func_nsf.h"
#include "NDA_func_simu.h"
#include "NDA_func_temp.h"

#include "NDA_func_gpu_basic.h"
#include "NDA_func_gpu_main_dec.h"

namespace NDA_FUNC_RMCEPSR_GPU {
    void Calc_Delta_NR_GPU();
    void Confirm_Move_GPU();
    void Calc_PDF_GPU();

} 

#endif 
