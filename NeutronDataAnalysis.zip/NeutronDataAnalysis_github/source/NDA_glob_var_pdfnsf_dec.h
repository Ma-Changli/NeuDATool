extern  int     **       num_atompair_inatomtype_arr_2d      ;
extern  double  **       num_atompair_inatomtype_mean_arr_2d ;
extern  double  **       pdf_atompair_inatomtype_arr_2d      ;
//extern  double  **       pdf_atompair_inatomtype_sum_arr_2d      ;

extern  double    *  val_qqq_simu_arr ;
extern  double    *  val_qqq_simu_set_arr ;
extern  double **       val_hq_atompair_simu_arr_2d;  
extern  double **       val_hq_atompair_simu_set_arr_2d;  

extern  double **       val_nsf_sample_simu_sum_arr_2d     ;
extern  double *        val_nsf_sample_simu_sum_arr_2d_mpi ;  

extern  double **       val_nsf_sample_simu_sum_set_arr_2d     ;
extern  double *        val_nsf_sample_simu_sum_set_arr_2d_mpi ;  

extern  double   ** val_nsf_diff_sample_arr_2d    ;  
extern  double   ** val_nsf_diff_sample_fit_arr_2d ;  
extern  double   ** chi_nsf_diff_sample_fit_arr_2d ;  

extern  double   ** val_nsf_diff_atompair_arr_2d ;  
extern  double   ** val_nsf_diff_atompair_fit_arr_2d ;  

extern  double **       delta_nsf_datapdf_forpot_arr_2d ;












