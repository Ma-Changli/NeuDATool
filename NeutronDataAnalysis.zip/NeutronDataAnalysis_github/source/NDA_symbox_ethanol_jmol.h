//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_ETHANOL_JMOL_H
#define NDA_SYMBOX_ETHANOL_JMOL_H  1

#include  "NDA_symbox.h"
#include  "NDA_mole_ethanol_jmol.h"

class NDA_symbox_ethanol_jmol : public NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_ethanol_jmol;

    public:
    NDA_symbox_ethanol_jmol(){};
    ~NDA_symbox_ethanol_jmol(){};

   // void Initialize_H2O(
    void Initialize(
	    int     & num_mol_input, 
	    bool          set_coord
	    );

  //  void   Initialize_H2O_Sample(int  num_mol_input,  string name_sample,  bool  set_nuc_name);
 //   void   Initialize_Sample(int  num_mol_input,  string name_sample,  bool  set_nuc_name);

//Users only need to copy the function to the new class and change the NDA_symbox_ethanol to your own box class name
//    void   ClassifyAtomToAtomTypeBasic_MapSample(vector<NDA_symbox_ethanol>  sim_box_sample_vec, int index_procs);

};

#endif 
