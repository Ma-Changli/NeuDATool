#ifndef NDA_GLOB_VAR_RUN_DEF_H
#define NDA_GLOB_VAR_RUN_DEF_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"

//==================================================
//Variable of run configuration
int    argc_glob;
char**  argv_glob;

clock_t time_start;
clock_t time_finish;

int  index_arr_local;

stringstream    name_file_pot_ss;
string          name_file_pot_str;
ofstream      output_file_pot;

stringstream    name_file_local_ss;
string          name_file_local_str;
ofstream      output_file_local;
ofstream      output_file_local_01;

stringstream    name_file_waste_ss;
string          name_file_waste_str;
ofstream      output_file_waste;

ofstream      output_file_debug;

string         result_directory;
stringstream   stringstream_single;

string   name_sample_chem_str;

string     extension_file_gro;
string     extension_file_pot;
string     extension_file_pdf;
string     extension_file_nsf;



// Delete old results file 
string cmd_rm_str;
string cmd_mkdir_str;

int      num_char_procs;
int      num_char_step ;

int    num_procs;
int    index_procs; 
int    index_procs_root;


// Whether print debug information 
// is_print_debug_info = true;
bool  is_print_debug_info; 

// Whether print intermediate result  
bool   is_print_inter_result;
// Whether print emperical potential functions   
bool   is_print_poisson_function;

double temperature; // K 

//  double kT = CLHEP::k_Boltzmann * temperature;
double kT; //kJ
double inverse_kT;



#endif 
