#ifndef NDA_FUNC_NEW_ARRAY_PDFPOT_H
#define NDA_FUNC_NEW_ARRAY_PDFPOT_H  1

#include <memory.h> // or //#include <string.h>

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_glob_var_pdfnsf_dec.h"

namespace NDA_FUNC_NEW_ARRAY_PDFPOT
{

    void New_Array_RefPot();
    void New_Array_PDF();


}

#endif
