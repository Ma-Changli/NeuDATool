//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_DMSO_70_MDMOL_H
#define NDA_SYMBOX_DMSO_70_MDMOL_H  1

#include  "NDA_symbox.h"
#include  "NDA_mole_ctri_jmol.h"
#include  "NDA_mole_atri_jmol.h"
#include  "NDA_mole_dmso_jmol.h"

class NDA_symbox_dmso_70_mdmol : public NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_ctri_jmol;
    friend class NDA_mole_atri_jmol;
    friend class NDA_mole_dmso_jmol;

    public:
    NDA_symbox_dmso_70_mdmol(){};
    ~NDA_symbox_dmso_70_mdmol(){};

    void Initialize(
	    int  & num_mol_input, 
	    bool   set_coord
	    );


    //Users only need to copy the function to the new class and change the NDA_symbox_h2o to your own box class name
    //    void   ClassifyAtomToAtomTypeBasic_MapSample(vector<NDA_symbox_h2o>  sim_box_sample_vec, int index_procs);

};

#endif 
