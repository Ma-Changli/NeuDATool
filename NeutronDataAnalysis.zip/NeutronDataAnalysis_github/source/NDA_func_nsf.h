//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_NSF_H
#define NDA_FUNC_NSF_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_NSF {


    void  Calculate_NSF(
	    double  *nsf_atompair_innuc_arr,  
	    double  *pdf_atompair_innuc_arr,  
	    double  *r_mean_arr,
	    double  *q_mean_arr,
	    int      num_bin_pdf,
	    int      num_bin_nsf,
	    double   binsize_r, 
	    double   ccbb, 
	    double   factor_nsf,
	    double   pi_rho_4
	    );



    void  Calculate_HQ(
	    double  *hq_atompair_innuc_arr,  
	    double  *pdf_atompair_innuc_arr,  
	    double  *r_mean_arr,
	    double  *q_mean_arr,
	    int      num_bin_pdf,
	    int      num_bin_nsf,
	    double   binsize_r, 
	    double   pi_rho_4
	    );


    void  Calculate_NSF_Sample(
	    double **nsf_atompair_innuc_arr_2d,  
	    double **pdf_atompair_innuc_arr_2d,  
	    int      num_sample_exp, 
	    double  *r_mean_arr,
	    double  *q_mean_arr,
	    int      num_bin_pdf,
	    int      num_bin_nsf,
	    double   binsize_r, 
	    double   ccbb, 
	    double   factor_nsf,
	    double   pi_rho_4,
	    int      index_atompair
	    );


} // End namespace NDA_FUNC

#endif 
