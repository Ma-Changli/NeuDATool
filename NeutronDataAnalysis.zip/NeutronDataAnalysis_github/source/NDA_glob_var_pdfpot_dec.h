// Empirical Potential  Poisson , poisson
//==========================================================================
extern  double   val_sigma_qqq_emp ;
extern  double   val_sigma_rad_emp ;
extern  double   rad_poisson_min ;
extern  double   rad_poisson_max ;
 
extern  int      num_poisson_emp;
 
extern  double  interval_rad_base; // Why -2.0 * rad_poisson_min?
extern  double *	val_rad_poisson_emp_arr;
 
extern  double  **  factor_poisson_emp_atompair_sum_arr_2d        ;
extern  double  **  factor_poisson_emp_atompair_fit_arr_2d ;

extern  double  **  factor_poisson_emp_sample_arr_2d ;

extern  double  **  pot_poisson_emp_rad_arr_2d ;
extern  double  **  pot_poisson_emp_qqq_arr_2d ;

