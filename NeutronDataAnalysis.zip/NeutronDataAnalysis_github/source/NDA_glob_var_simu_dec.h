#ifndef NDA_GLOB_VAR_SIMU_DEC_H
#define NDA_GLOB_VAR_SIMU_DEC_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"

 
//==================================================
//Variable of configure simulation
 
extern  bool   use_epsr_or_rmc;
 
// Whether truncate reference potential by function
extern  bool   is_truncted_by_function;
extern  bool   is_move_atom;
 
// Update simulation potential criteria 
// True means use movement steps, false means use accept ratio as update pot criteria
extern  bool     is_use_step_to_update_pot;  
 
// If is_use_step_to_update_pot = true,  edit below:
extern  int      num_step_start_update_pot;
extern  int      num_step_update_pot;
 
// If is_use_step_to_update_pot = false, set accept_ratio_move_cut  
extern  double   accept_ratio_move_cut;
extern  double   accept_ratio_move_cut_mc; // For MC
extern  double   accept_ratio_move_cut_ep; // For EPMC


// True means finish program use total simulation step as criteria
extern  bool    is_finish_by_step;
// is_finish_by_step = true;
extern  int       num_step_finish;
 
// Whether select molecules in simulation randomly or in sequence, true means randomly 
extern  bool     random_select_move_mol;
 
extern  double   angle_rot_max_degree; 
extern  double   ratio_rot;
extern  double   ratio_mov_atom;
 
extern  double   dist_trans_max_mol;
 
extern  double   dist_trans_max_atom;
 
extern  double   dist_trans_max;
 
extern  double   angle_rot_max_radian;


  
  //=========================
  
extern  double ** para_pot_lj_atomtype_inepsr_arr_2d;
extern  double ** para_pot_ep_atomtype_inepsr_arr_2d;
  
extern  int     *  index_atomtype_00_inatompair_arr;
extern  int     *  index_atomtype_01_inatompair_arr;
  
extern  double  *           factor_pot_atompair_arr;
  
extern  double  *                  pot_atompair_arr;
extern  double  *            delta_pot_atompair_arr;
  
  
extern  double        binsize_rad;
extern  double    val_rad_cut_max;
extern  int           binnumb_rad;
extern  double  volume_factor_rad;
extern  double          pi_rho_4 ;
  
extern  double   * binmean_rad_arr;
extern  double   * binvolu_rad_arr;

  
//extern  int    **       num_atompair_inepsr_arr_2d             ;
extern unsigned long  long int    **       num_atompair_inepsr_arr_2d             ;
extern  double **  num_atompair_inepsr_mean_arr_2d             ;
extern  double **       pdf_atompair_inepsr_arr_2d             ;
extern  double **       pdf_atompair_inepsr_sum_arr_2d         ;
extern  int    ** delta_num_atompair_inepsr_arr_2d             ;
extern  int    ** delta_num_atompair_inepsr_arr_tot_2d         ;
  
extern  double **    pot_lj_atompair_inepsr_arr_2d             ;
extern  double **    pot_ep_atompair_inepsr_arr_2d             ;
extern  double **   pot_rep_atompair_inepsr_arr_2d             ;
extern  double **   pot_ref_atompair_inepsr_arr_2d             ;
  
extern  double**    pot_emp_atompair_inepsr_sum_arr_2d             ;
extern  double**    pot_emp_atompair_inepsr_fit_arr_2d  ;
extern  double**    pot_tot_atompair_inepsr_arr_2d             ;
  
  
  
extern  double         **       pot_emp_sample_inepsr_arr_2d; ;
  
  
extern  double  * c_min_arr        ;
extern  double  * r_min_arr        ; ;
extern  double  * sigma_rep_arr    ;
extern  double  * g_lim_arr        ;
  
extern  double  * r_minpt_arr      ;
extern  double  * r_maxpt_arr      ;
extern  double  * sigma_c_arr      ;
  
extern  double      ** truncate_table_Coulomb_arr_2d   ;
extern  double      ** truncate_table_NonCoulomb_arr_2d;
  
extern  int   index_atomtype_00_inbox; ;
extern  int   index_atomtype_01_inbox; ;
extern  int   index_atompair_inbox;

//=================

extern  double   val_qqq_cut_min; 
extern  double   val_qqq_cut_max;         

extern  vector< vector< double > >           val_qqq_sample_data_vec_2d; 
extern  vector< vector< double > >           val_nsf_sample_data_vec_2d;
extern  vector< int >                      binnumb_qqq_sample_data_vec;


extern  int  binnumb_qqq_data;
extern  int  binnumb_qqq_simu; 

extern  double   **      val_qqq_sample_data_arr_2d; 
extern  double   **      val_nsf_sample_data_arr_2d;
extern  int      *   binnumb_qqq_sample_data_arr   ;

extern  double   **      val_qqq_sample_simu_arr_2d; 
extern  double   **      val_nsf_sample_simu_arr_2d;
extern  int      *   binnumb_qqq_sample_simu_arr   ;

extern  double   **      val_qqq_sample_simu_set_arr_2d; 
extern  double   **      val_nsf_sample_simu_set_arr_2d;
extern  int      *   binnumb_qqq_sample_simu_set_arr   ;

extern  double   binsize_qqq_simu_set;
extern  int      binnumb_qqq_simu_set;

extern  double   val_qqq_simu_min_set;
extern  double   val_qqq_simu_max_set;


extern  double   ** diff_nsf_sample_datasimu_arr_2d;  

//====================

extern  double ** matrix_weight_arr_2d     ;
extern  double *  matrix_weight_arr_2d_mpi ;

extern  double ** matrix_weight_rev_arr_2d     ;
extern  double *  matrix_weight_rev_arr_2d_mpi ;


#ifndef NDA_GLOB_VAR_CONST_H
#define NDA_GLOB_VAR_CONST_H  1
const unsigned num_para_pot_lj = 5;
const unsigned num_para_pot_ep = 5;
#endif
#endif 



// For  Fit_ExpPot() VVVV
extern  double max_factor_poisson;
extern  double max_step_poisson;
extern  double step_factor_poisson;

extern  double chisq_pre;
extern  double chisq_new;
extern  double accept;
extern  double accept_ratio;
extern  double exponent;
// For  Fit_ExpPot() AAAA 



