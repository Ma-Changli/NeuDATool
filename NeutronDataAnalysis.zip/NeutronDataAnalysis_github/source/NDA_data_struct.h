//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_DATATYPE_STRUCT_H
#define NDA_DATATYPE_STRUCT_H

#include <string>
#include "CLHEP/Vector/ThreeVector.h"

using namespace std;

typedef struct
{
   double   val_q;
   double   err_q;
   double   val_sigma; // The cross section
   double   err_sigma;
}
nsf_struct;


typedef struct
{
//   string name_nuclide;
   CLHEP::Hep3Vector             coord_xyz;
   double             scatt_length_neutron;
//   double scatt_length_x;
}
coord_b_atom_struct;



typedef struct
{
    string   name_atom;
    string   name_element;
    int      num_nuc;
    string   name_nuc_arr[3];
    double   b_nuc_arr[3];
    double   ratio_nuc_arr[3];
}
atom_nuc_struct;


typedef struct
{
    string  name_atom;
    double  para_pot_lj[10];
    double  para_pot_ep[10];
}
atom_rep_struct;



//====================== Will be removed in the future
typedef struct
{
   string   name_isotope;
   string   name_element;
   string   name_atom_gro;
   string   name_atom_sans;
   string   name_residue;
   string   name_molecule;

   int      index_molecule;
   int      index_frame;
   int      index_residue;
   int      index_atom;

   //   double   coord_xyz[3];
   CLHEP::Hep3Vector coord_xyz;

   double   velocity_xyz[3];

   double scatt_length_neutron;
   double scatt_length_x;

}
atom_struct;






#endif
