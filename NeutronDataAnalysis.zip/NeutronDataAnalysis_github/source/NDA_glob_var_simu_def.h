#ifndef NDA_GLOB_VAR_SIMU_DEF_H
#define NDA_GLOB_VAR_SIMU_DEF_H  1

#include "NDA_incl_std.h"
#include "NDA_incl_clhep.h"
#include "NDA_incl_nda.h"


//==================================================
//Variable of configure simulation

bool   use_epsr_or_rmc;

// Whether truncate reference potential by function
bool   is_truncted_by_function;
bool   is_move_atom;

// Update simulation potential criteria 
// True means use movement steps, false means use accept ratio as update pot criteria
bool     is_use_step_to_update_pot;  

// If is_use_step_to_update_pot = true,  edit below:
int      num_step_start_update_pot;
int      num_step_update_pot;

// If is_use_step_to_update_pot = false, set accept_ratio_move_cut  
double   accept_ratio_move_cut;
double   accept_ratio_move_cut_mc; // For MC
double   accept_ratio_move_cut_ep; // For EPMC

// True means finish program use total simulation step as criteria
bool    is_finish_by_step;
// is_finish_by_step = true;
int       num_step_finish;

// Whether select molecules in simulation randomly or in sequence, true means randomly 
bool     random_select_move_mol;

double   angle_rot_max_degree; 
double   ratio_rot;
double   ratio_mov_atom;

double   dist_trans_max_mol;

double   dist_trans_max_atom;

double   dist_trans_max;

double   angle_rot_max_radian;



//=========================

double ** para_pot_lj_atomtype_inepsr_arr_2d;
double ** para_pot_ep_atomtype_inepsr_arr_2d;

int     *  index_atomtype_00_inatompair_arr;
int     *  index_atomtype_01_inatompair_arr;

double  *           factor_pot_atompair_arr;

double  *                  pot_atompair_arr;
double  *            delta_pot_atompair_arr;


double        binsize_rad;
double    val_rad_cut_max;
int           binnumb_rad;
double  volume_factor_rad;
double          pi_rho_4 ;

double   * binmean_rad_arr;
double   * binvolu_rad_arr;






//int    **       num_atompair_inepsr_arr_2d             ;
unsigned long long int   **       num_atompair_inepsr_arr_2d             ;
double **  num_atompair_inepsr_mean_arr_2d             ;
double **       pdf_atompair_inepsr_arr_2d             ;
double **       pdf_atompair_inepsr_sum_arr_2d             ;
int    ** delta_num_atompair_inepsr_arr_2d             ;
int    ** delta_num_atompair_inepsr_arr_tot_2d         ;

double **    pot_lj_atompair_inepsr_arr_2d             ;
double **    pot_ep_atompair_inepsr_arr_2d             ;
double **   pot_rep_atompair_inepsr_arr_2d             ;
double **   pot_ref_atompair_inepsr_arr_2d             ;

double**    pot_emp_atompair_inepsr_sum_arr_2d             ;
double**    pot_emp_atompair_inepsr_fit_arr_2d  ;
double**    pot_tot_atompair_inepsr_arr_2d             ;



double         **       pot_emp_sample_inepsr_arr_2d; ;


double  * c_min_arr        ;
double  * r_min_arr        ; ;
double  * sigma_rep_arr    ;
double  * g_lim_arr        ;

double  * r_minpt_arr      ;
double  * r_maxpt_arr      ;
double  * sigma_c_arr      ;

double      ** truncate_table_Coulomb_arr_2d   ;
double      ** truncate_table_NonCoulomb_arr_2d;

int   index_atomtype_00_inbox; ;
int   index_atomtype_01_inbox; ;
int   index_atompair_inbox;

//=================

double   val_qqq_cut_min; 
double   val_qqq_cut_max;         

vector< vector< double > >           val_qqq_sample_data_vec_2d; 
vector< vector< double > >           val_nsf_sample_data_vec_2d;
vector< int >                      binnumb_qqq_sample_data_vec;

int  binnumb_qqq_data;
int  binnumb_qqq_simu; 

double   **      val_qqq_sample_data_arr_2d; 
double   **      val_nsf_sample_data_arr_2d;
int      *   binnumb_qqq_sample_data_arr   ;

double   **      val_qqq_sample_simu_arr_2d; 
double   **      val_nsf_sample_simu_arr_2d;
int      *   binnumb_qqq_sample_simu_arr   ;

double   **      val_qqq_sample_simu_set_arr_2d; 
double   **      val_nsf_sample_simu_set_arr_2d;
int      *   binnumb_qqq_sample_simu_set_arr   ;

double   binsize_qqq_simu_set;
int      binnumb_qqq_simu_set;

double   val_qqq_simu_min_set;
double   val_qqq_simu_max_set;

double   ** diff_nsf_sample_datasimu_arr_2d;  

//====================

double ** matrix_weight_arr_2d     ;
double *  matrix_weight_arr_2d_mpi ;

double ** matrix_weight_rev_arr_2d     ;
double *  matrix_weight_rev_arr_2d_mpi ;


#ifndef NDA_GLOB_VAR_CONST_H
#define NDA_GLOB_VAR_CONST_H  1
const unsigned num_para_pot_lj = 5;
const unsigned num_para_pot_ep = 5;
#endif
#endif 


// For  Fit_ExpPot() VVVV
double max_factor_poisson;
double max_step_poisson;
double step_factor_poisson;

double chisq_pre;
double chisq_new;
double accept;
double accept_ratio;
double exponent;
// For  Fit_ExpPot() AAAA 





