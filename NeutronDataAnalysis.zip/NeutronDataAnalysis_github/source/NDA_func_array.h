//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_ARRAY_H
#define NDA_FUNC_ARRAY_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

static double * default_val_arr;


namespace NDA_FUNC_ARRAY {

    void Generate_Q_Mean_Arr(
	    vector< double >   q_mean_data_vec, 
	    double           * q_mean_data_arr 
	    );

    double Calculate_Chisq_2Graph( 
	    double  *val_graph_test_arr,
	    double  *err_graph_test_arr,
	    double  *val_graph_calc_arr,
	    int      num_bin
	    );


    void Accumulate_NFS( 
	    double  **nsf_atompair_innuc_arr_2d,
	    double   *nsf_total_inbox_arr,
	    int       num_nucpair_inbox,
	    int       num_bin_nsf
	    );

    //==============================================================
    void Accumulate_NSF_Sample( 
	    double  ***nsf_atompair_innuc_arr_3d,
	    double   **nsf_total_inbox_arr_2d,
	    int        num_nucpair_inbox,
	    int        num_sample_exp,
	    int        num_bin_nsf
	    );


    void  PrintNSFToFile(
	    std::string  name_dir, 
	    std::string  name_file,
	    double      *q_mean_arr,
	    double      *nsf_total_inbox_arr,
	    int          num_bin_nsf
	    );


    void Smooth_NSF_Vec(
	    vector< nsf_struct >       q_nsf_input_vec,
	    vector< nsf_struct >  &   q_nsf_output_vec,
	    int                          num_bin_added
	    );

    void Rebin_NSF_To_Data(
	    vector< nsf_struct >       q_nsf_basic_vec,
	    vector< nsf_struct >       q_nsf_input_vec,
	    vector< nsf_struct >  &    q_nsf_output_vec
	    );

    void Rebin_NSF_To_Data_arr(
	    double    *     nsf_basic_arr,
	    double    *       q_basic_arr,
	    int             num_bin_basic,
	    double    *     nsf_input_arr,
	    double    *       q_input_arr,
	    int             num_bin_input,
	    double    *     nsf_output_arr
	    );

    void Rebin_NSF_To_Sim_arr(
	    double    *     nsf_basic_arr,
	    double    *       q_basic_arr,
	    int             num_bin_basic,
	    double    *     nsf_input_arr,
	    double    *       q_input_arr,
	    int             num_bin_input,
	    double    *     nsf_output_arr
	    );

    void Subtract_NSF_Vec(
	    vector< nsf_struct >       q_nsf_00_vec,
	    vector< nsf_struct >       q_nsf_01_vec,
	    vector< nsf_struct >  &    q_nsf_output_vec
	    ); 

    void Subtract_Array(
	    double * arr_00,
	    double * arr_01,
	    double * arr_result,
	    int num_bin
	    );



    void Add_Array_To1_Double(
	    double * arr_00,
	    double * arr_01,
	    double   scale,
	    int      num_bin
	    );


    void Add_Array_To1_Double_OMP(
	    double * arr_00,
	    double * arr_01,
	    double   scale,
	    int      num_bin
	    );



    void   Add_Array_To1_WeightedAverage_Double(
	    double  * arr_00,
	    double  scale_00,
	    double  * arr_01,
	    double  scale_01,
	    int      num_bin
	    );

    void Add_Array_To1_Int(
	    int     * arr_00,
	    int     * arr_01,
	    int        scale,
	    int      num_bin
	    );

    void Add_Array_To1_Int(
	   unsigned long long int     * arr_00,
	    int     * arr_01,
	    int        scale,
	    int      num_bin
	    );


    double  Cal_Chisq_2Array_Double(
	    double * arr_00,
	    double * arr_01,
	    double * arr_chi,
	    int      num_bin,
	    bool     have_x_cut = false,
	    double * arr_x = default_val_arr, // new double[3],
	    double   x_min =  0.0,
	    double   x_max = 50.0,
	    bool     have_err = false,
	    double * err_00 = default_val_arr //new double[3]
	    );


    double  Cal_Chisq_2Array_Double_OMP(
	    double * arr_00,
	    double * arr_01,
	    double * arr_chi,
	    int      num_bin,
	    bool     have_x_cut = false,
	    double * arr_x = default_val_arr, // new double[3],
	    double   x_min =  0.0,
	    double   x_max = 50.0,
	    bool     have_err = false,
	    double * err_00 = default_val_arr //new double[3]
	    );


    //    double  Cal_Chisq_2Array_Double(
    //	    double * arr_00,
    //	    double * arr_01,
    //	    int      num_bin,
    //	    bool     have_x_cut,
    //	    double * arr_x,
    //	    double   x_min,
    //	    double   x_max,
    //	    bool     have_err,
    //	    double * err_00
    //	    );
    //
    //    double  Cal_Chisq_2Array_Double(
    //	    double * arr_00,
    //	    double * arr_01,
    //	    int      num_bin,
    //	    bool     have_x_cut,
    //	    double * arr_x,
    //	    double   x_min,
    //	    double   x_max
    //	    );
    //
    //
    //    double  Cal_Chisq_2Array_Double(
    //	    double * arr_00,
    //	    double * arr_01,
    //	    int      num_bin,
    //	    bool     have_err,
    //	    double * err_00
    //	    );





    void Add_1Array_To1Array(
	    double * arr_00,
	    double * arr_output,
	    int      num_bin
	    );


    void Add_2Array_To1Array(
	    double * arr_00,
	    double * arr_01,
	    double * arr_output,
	    int      num_bin
	    );

    void Add_2Array_To1Array_Double_AddEmp(
	    double   * arr_00,
	    double   scale_00,
	    double   * arr_01,
	    double   scale_01,
	    double   * arr_output,
	    int        num_bin,
	    bool     have_x_cut = false,
	    double   * arr_x = default_val_arr, //new double[3],
	    double     x_min = 0.0,
	    double     x_max = -100
	    );

    //    void Add_2Array_To1Array_Double_AddEmp(
    //	    double   * arr_00,
    //	    double   scale_00,
    //	    double   * arr_01,
    //	    double   scale_01,
    //	    double   * arr_output,
    //	    int        num_bin,
    //	    bool     have_x_cut,
    //	    double   * arr_x,
    //	    double     x_min,
    //	    double     x_max
    //	    );
    //
    //
    //    void Add_2Array_To1Array_Double_AddEmp(
    //	    double   * arr_00,
    //	    double   scale_00,
    //	    double   * arr_01,
    //	    double   scale_01,
    //	    double   * arr_output,
    //	    int        num_bin
    //	    );




    void Add_3Array_To1Array(
	    double * arr_00,
	    double * arr_01,
	    double * arr_02,
	    double * arr_output,
	    int      num_bin
	    );



    double Multiply_2Array_to_1Scalar(double *arr_00, int num_bin_00, int *arr_01,  int num_bin_01);
    double Multiply_2Array_to_1Scalar(double *arr_00, int num_bin_00, long *arr_01,  int num_bin_01);
    double Multiply_2Array_to_1Scalar(double *arr_00, int num_bin_00, unsigned  long long int *arr_01,  int num_bin_01);
    void   Multiply_2Array_to_1stArray(double  *arr_00,  double *arr_01, int num_bin);

    void Divide_Array_Int(
	    int     * arr_00,
	    int      divisor,
	    int      num_bin
	    );

    void Multiply_Array_Int(
	    int     * arr_00,
	    int       factor,
	    int      num_bin
	    );

    void Multiply_Array_Int(
	    long     * arr_00,
	    int       factor,
	    int      num_bin
	    );

    void Multiply_Array_Int(
	   unsigned  long long int    * arr_00,
	    int       factor,
	    int      num_bin
	    );


    void Multiply_Array_Double(
	    int     * arr_00,
	    double       factor,
	    int      num_bin
	    );



    //    void Divide_Array_Int(
    //	    int     * arr_00,
    //	    int       factor,
    //	    int      num_bin
    //	    );


    void Translate_Array(
	    double  * arr_00,
	    double     delta,
	    int      num_bin
	    );

    void Translate_Vector(
	    vector < double >  & arr_00,
	    double     delta,
	    int      num_bin
	    );

} // End namespace NDA_FUNC

#endif 
