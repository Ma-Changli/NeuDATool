//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_SYMBOX_H2O_JMOL_H
#define NDA_SYMBOX_H2O_JMOL_H  1

#include  "NDA_symbox.h"
#include  "NDA_mole_h2o_jmol.h"

class NDA_symbox_h2o_jmol : public NDA_symbox {

    friend class NDA_atom;
    friend class NDA_molecule;
    friend class NDA_mole_h2o_jmol;

    public:
    NDA_symbox_h2o_jmol(){};
    ~NDA_symbox_h2o_jmol(){};

   // void Initialize_H2O(
    void Initialize(
	    int     & num_mol_input, 
	    bool          set_coord
	    );

  //  void   Initialize_H2O_Sample(int  num_mol_input,  string name_sample,  bool  set_nuc_name);
 //   void   Initialize_Sample(int  num_mol_input,  string name_sample,  bool  set_nuc_name);

//Users only need to copy the function to the new class and change the NDA_symbox_h2o to your own box class name
//    void   ClassifyAtomToAtomTypeBasic_MapSample(vector<NDA_symbox_h2o>  sim_box_sample_vec, int index_procs);

};

#endif 
