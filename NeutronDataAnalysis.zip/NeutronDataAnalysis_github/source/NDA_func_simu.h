//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_SIMU_H
#define NDA_FUNC_SIMU_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_SIM {

    void Sort_atom_moved_to_atomtype( 
	    vector< int >  index_nuc_atom_moved_inbox_vec,
	    vector< int >  index_atom_moved_innuc_inbox_1d_vec,
	    vector< CLHEP::Hep3Vector >  delta_coord_atom_moved_inbox_vec,
	    int      num_atom_moved,
	    vector< int >            & index_nuc_moved_inbox_vec,
	    vector< vector< int > >  & index_atom_moved_innuc_inbox_vec,
	    vector< vector< CLHEP::Hep3Vector > > & delta_coord_atom_moved_innuc_inbox_vec
	    );


    void Update_coord_atom_inatomtype_inbox_vec( 
	    vector<  vector< CLHEP::Hep3Vector >  > & coord_atom_inbox_innuc_inbox_vec, 
	    vector< int >             index_nuc_moved_inbox_vec,
	    vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
	    vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
	    double boxsize
	    );

} // End namespace NDA_FUNC

#endif 
