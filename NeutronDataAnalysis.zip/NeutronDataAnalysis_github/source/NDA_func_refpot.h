#ifndef NDA_FUNC_REFPOT_H
#define NDA_FUNC_REFPOT_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

#include <map>
//#include  "NDA_header_main.h"

#include "NDA_func_array.h"
#include "NDA_func_pdf.h"
#include "NDA_func_pdf_gpu.h"
#include "NDA_func_pot.h"

namespace NDA_FUNC_REFPOT{

    void   Set_AtomType_SiO2(); //Users Edit it 
    void   Set_Para_RefPot_SiO2(); //Users Edit it
    void   Set_Para_RefPot_Cut_SiO2(); //Users Edit it

    void   Set_AtomType_H2O(); //Users Edit it 
    void   Set_Para_RefPot_H2O(); //Users Edit it
    void   Set_Para_RefPot_Cut_H2O(); //Users Edit it

    void   Set_AtomType_H2O_JMOL(); //Users Edit it 
    void   Set_Para_RefPot_H2O_JMOL(); //Users Edit it
    void   Set_Para_RefPot_Cut_H2O_JMOL(); //Users Edit it

    void   Set_AtomType_ETHANOL_80(); //Users Edit it 
    void   Set_Para_RefPot_ETHANOL_80(); //Users Edit it
    void   Set_Para_RefPot_Cut_ETHANOL_80(); //Users Edit it

    void   Set_AtomType_DMSO_90(); //Users Edit it 
    void   Set_Para_RefPot_DMSO_90(); //Users Edit it
    void   Set_Para_RefPot_Cut_DMSO_90(); //Users Edit it

    void   Set_AtomType_DMSO_50(); //Users Edit it 
    void   Set_Para_RefPot_DMSO_50(); //Users Edit it
    void   Set_Para_RefPot_Cut_DMSO_50(); //Users Edit it

    void   Set_AtomType_DMSO_60(); //Users Edit it 
    void   Set_Para_RefPot_DMSO_60(); //Users Edit it
    void   Set_Para_RefPot_Cut_DMSO_60(); //Users Edit it

    void   Set_AtomType_DMSO_70(); //Users Edit it 
    void   Set_Para_RefPot_DMSO_70(); //Users Edit it
    void   Set_Para_RefPot_Cut_DMSO_70(); //Users Edit it

    void   Set_AtomType_DMSO_80(); //Users Edit it 
    void   Set_Para_RefPot_DMSO_80(); //Users Edit it
    void   Set_Para_RefPot_Cut_DMSO_80(); //Users Edit it

    void   Set_AtomType_PDEA_80(); //Users Edit it 
    void   Set_Para_RefPot_PDEA_80(); //Users Edit it
    void   Set_Para_RefPot_Cut_PDEA_80(); //Users Edit it

    void   Set_Array_RefPot();

    void   Calc_Pot_Box();

    void  Read_AtomType_FromFile(vector< string >  name_file_vec, vector< string > & name_atomtype_vec); 
    void  Read_Para_RefPot_FromFile(vector< string >  name_file_vec,
	    std::map <string, double*> & para_pot_lj,
	    std::map <string, double*> & para_pot_ep
	    );

    void  Read_Para_RefPot_FromFile(
	    vector< string >             name_file_vec,
	    vector< atom_rep_struct >  & atom_rep_vec
	    );

} // End namespace NDA_FUNC

#endif 
