#ifndef NDA_FUNC_ATOMTYPE_H
#define NDA_FUNC_ATOMTYPE_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"

namespace NDA_FUNC_ATOMTYPE {

    void Set_Para_AtomType();
    void Print_Para_AtomType();

} // End namespace NDA_FUNC
#endif 
