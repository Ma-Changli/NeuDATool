#ifndef NDA_FUNC_PRINTPOT_H
#define NDA_FUNC_PRINTPOT_H  1

using namespace std;

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"


#include "NDA_func_file.h"

namespace NDA_FUNC_PRINTPOT {

    void Print_Pot();
}


#endif 
