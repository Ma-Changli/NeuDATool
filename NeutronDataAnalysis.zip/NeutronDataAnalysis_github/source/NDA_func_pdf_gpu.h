//EPSR++ is an open source C++ program for neutron data analysis. It is developed
//in Institute of High Energy Physics (IHEP) and Dongguan Neutron Science Center 
//(CSNS) by Changli Ma (machangli@ihep.ac.cn).
//EPSR++ adheres to GNU General Public License 2 (GPLv2).

#ifndef NDA_FUNC_PDF_GPU_H
#define NDA_FUNC_PDF_GPU_H  1

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include <cstdlib>
#include <time.h>

#include <string>
#include <vector>
#include <map>

#include  "CLHEP/Vector/ThreeVector.h"
#include  "NDA_data_struct.h"

#include <time.h>
#include <string>
#include <memory.h>
#include <omp.h>

using namespace std;
using namespace CLHEP;

//typedef void(*func_lj_pot) (double epsilonm, double sigma, double *table_pot_arr);  

namespace NDA_FUNC_PDF_GPU {

    extern "C" {

	void Calculate_NR_ForPDF( 
		vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
		vector< int >                  index_mol_atom_00_vec, 
		vector< int >                  index_mol_atom_01_vec, 
		double                        *r_mean_pot_arr,
	//	int                           *num_atompair_inepsr_arr, 
//		long                           *num_atompair_inepsr_arr, 
	unsigned long long int                           *num_atompair_inepsr_arr, 
		double                         boxsize,
		int                            num_bin_pot,
		double                         binsize_pot,
		double                         r_cut_pot  // this value is useless !!!
		);


	void Calculate_NR( 
		vector< CLHEP::Hep3Vector > coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector > coord_atom_01_vec, 
		vector< int > index_mol_atom_00_vec, 
		vector< int > index_mol_atom_01_vec, 
		double  *r_mean_pot_arr,
	//	int     *num_atompair_inepsr_arr, 
		unsigned long long int  *num_atompair_inepsr_arr, 
		double   boxsize,
		int      num_bin_pot,
		double   binsize_pot,
		double   r_cut_pot  // this value is useless !!!
		);


	bool  Calculate_Delta_NR( 
		vector< CLHEP::Hep3Vector > coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector > coord_atom_01_vec, 
		vector< int >               index_mol_atom_00_vec, 
		vector< int >               index_mol_atom_01_vec, 
		int                                    index_atomtype_00_inbox,
		int                                    index_atomtype_01_inbox,
		vector< int >                          index_atomtype_movedatomtype_inbox_vec,
		vector< vector< int > >                index_atom_inatomtype_movedatom_inmovedatomtype_inbox_vec_2d,
		vector< vector< CLHEP::Hep3Vector > >  delta_coord_movedatom_inmovedatomtype_inbox_vec_2d,
		int        * delta_num_atompair_inepsr_arr, 
		double       boxsize,
		int          num_bin_pot,
		double       binsize_pot,
		double       r_cut_pot  // this value is useless !!!
		);



	void    Calculate_Delta_NR_BasicSample( 
		vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
		int                            index_atomtype_00_inbox,
		int                            index_atomtype_01_inbox,
		vector< int >             index_nuc_moved_inbox_vec,
		vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
		vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
		vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d,
		vector< int >   num_nuc_sample_vec,
		int      num_sample_exp,
		double  *r_mean_arr,
		int     *delta_num_atompair_innuc_arr, 
		int   ***delta_num_nucpair_innuc_inbox_sample_arr_3d, 
		double   boxsize,
		int      num_bin_pdf,
		double   binsize_pdf_sim
		);



	void    Calculate_NR_BasicSample( 
		vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
		int                            index_atomtype_00_inbox,
		int                            index_atomtype_01_inbox,
		vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d,
		vector< int >   num_nuc_sample_vec,
		int      num_sample_exp,
		double  *r_mean_arr,
		int     *num_atompair_innuc_arr, 
		int   ***num_nucpair_innuc_inbox_sample_arr_3d, 
		double   boxsize,
		int      num_bin_pdf,
		double   binsize_pdf_sim
		);


	void    Calculate_Delta_NR_BasicSample( 
		vector< CLHEP::Hep3Vector >    coord_atom_00_vec, 
		vector< CLHEP::Hep3Vector >    coord_atom_01_vec, 
		int                            index_atomtype_00_inbox,
		int                            index_atomtype_01_inbox,
		vector< int >             index_nuc_moved_inbox_vec,
		vector< vector< int > >   index_atom_moved_innuc_inbox_vec,
		vector< vector< CLHEP::Hep3Vector > >  delta_coord_atom_moved_innuc_inbox_vec,
		vector< vector< vector< int > > > index_nuc_atom_sample_innuc_inbox_vec_3d,
		vector< int >   num_nuc_sample_vec,
		int      num_sample_exp,
		double  *r_mean_arr,
		int     *delta_num_atompair_innuc_arr, 
		int   ***delta_num_nucpair_innuc_inbox_sample_arr_3d, 
		double   boxsize,
		int      num_bin_pdf,
		double   binsize_pdf_sim
		);


    }

} // End namespace NDA_FUNC

#endif 
