#ifndef NDA_FUNC_MPI_BCAST_H
#define NDA_FUNC_MPI_BCAST_H  1

using namespace std;

#include <mpi.h>

#include "NDA_glob_var_run_dec.h"
#include "NDA_glob_var_box_dec.h"
#include "NDA_glob_var_simu_dec.h"
#include "NDA_glob_var_pdfpot_dec.h"
#include "NDA_glob_var_pdfnsf_dec.h"
#include "NDA_glob_var_epsr_cpu_dec.h"
#include "NDA_glob_var_epsr_gpu_dec.h"

#include "NDA_func_init_simubox.h"

namespace NDA_FUNC_MPI_BCAST
{
    void Broadcast_Simubox();
    void Broadcast_RefPot();
    void Broadcast_PotBox();

    void Broadcast_NSF_Init();
    void Broadcast_Info_Move();
    void Broadcast_Delta_NR();

    void Broadcast_NSF_RMCEPSR();

}

#endif

